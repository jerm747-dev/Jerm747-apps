PATCH BAY 0.1.1

PatchBay-0.1.1-Preview.apk installs alongside the existing Patch Bay app.
It has its own package ID and test certificate and is for device review.

PatchBay-0.1.1-unsigned.apk is the aligned build for com.jerm747.patchbay.
Sign it with the certificate used by the existing 0.1.0 download for an in-place upgrade.

  apksigner sign --ks "$PATCH_BAY_KEYSTORE" --ks-key-alias "$PATCH_BAY_KEY_ALIAS" --out PatchBay-0.1.1.apk PatchBay-0.1.1-unsigned.apk
  apksigner verify --print-certs PatchBay-0.1.1.apk

The current public download has certificate SHA-256
4f0baf449af63877f6d09b29f6e8482735e612437f91cfe8251f813581393c99.

For jerm747.dev, upload the signed PatchBay-0.1.1.apk under apps/download/
before overlaying the files in site-overlay/ onto the domain's document root.
The overlay contains only the changed Patch Bay web files.
Check /apps/ and /sites/patch-bay/ and verify that the new download installs.

The Git patch applies on top of main at 428f2bcdd506201cb83e2532acf1b912929b8638.
Run git am PatchBay-0.1.1.patch from the repository root to apply it.
