from pathlib import Path
import shutil
def patch(target):
 root=Path(__file__).parent
 shutil.copytree(root/'workshop-assets/player',target/'music-art',dirs_exist_ok=True)
 for n in ['game-music.js','game-music.css']:shutil.copyfile(root/n,target/n)
 for p in target.glob('*.html'):
  h=p.read_text()
  if 'gs-sound.js' in h:
   h=h.replace('<script src="/gs-sound.js"','<link rel="stylesheet" href="/game-music.css"><script src="/game-music.js"></script><script src="/gs-sound.js"')
   p.write_text(h)
 p=target/'gs-sound.js';h=p.read_text();a=h.index('const audio=new Audio();');b=h.index("window.addEventListener('storage'",a)
 h=h[:a]+"const audio=window.GSGameMusic.audio;function music(container){window.GSGameMusic.render(container);}\n"+h[b:];p.write_text(h)
 p=target/'assets/game-console.js';h=p.read_text().replace("panel.classList.remove('gc-controls');","panel.classList.remove('gc-controls','gs-music');")
 h=h.replace('function legacyMusic(){openSheet();',"let musicPausedFight=false;function legacyMusic(){const c=api.context();musicPausedFight=c.screen==='fight'&&!c.paused;openSheet();")
 h=h.replace("sheet.classList.add('hidden');musicOpen=false;", "sheet.classList.add('hidden');if(musicOpen&&musicPausedFight&&api.context().screen==='fight'&&api.context().paused)api.pause();musicPausedFight=false;musicOpen=false;")
 h=h.replace("panel.append(close);close.focus();", "close.className='gm-back-game';close.innerHTML='<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\"><path d=\"M7 6h10c3 0 4 4 5 10 0 3-3 4-5 1l-2-2H9l-2 2c-2 3-5 2-5-1C3 10 4 6 7 6z M7 9v5m-2-2h4m7-2h.1m3 3h.1\"/></svg> Back to game';(panel.querySelector('.gm-head')||panel).append(close);close.focus();")
 p.write_text(h)
