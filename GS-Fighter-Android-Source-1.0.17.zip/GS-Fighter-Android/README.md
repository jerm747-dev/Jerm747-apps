# GS Fighter — Android Workshop Edition 1.0.17

Version 1.0.17: the critical-health camera starts at 20% HP and magnifies the entire scene (fighters and background) by up to 20%, keeping both fighters in view. It eases out at 25% HP. Recovery now adds up to 5% of maximum health gradually over three simulation seconds, once per fighter per round. A faint striped segment shows the remaining potential health; no recovery label or countdown interrupts the fight. Existing default cinematic settings migrate automatically; custom settings are retained. KO slow motion is unchanged.

Parallax / Endless Run now opens a compact 14-fighter portrait picker with a large preview, saved runner, touch/keyboard/gamepad navigation and Start Run. Choose fighter pauses the current run; starting a chosen runner resets distance/hazards, while closing returns to the current run. Marked ditches join boxes and overhead duck gates. Jump, duck, double-speed run, V-wave and punch remain; visible kick and block buttons were added (C/F on keyboard, mapped attacks on pad). A ditch miss counts as a bump so practice keeps moving. Original workshop artwork is reused.



This is the Android wrapper for GS Fighter. The browser package remains unchanged.

## Install the APK

1. Copy **GS-Fighter-Android-1.0.17.apk** onto the handheld, its SD card, or Downloads folder.
2. Install it over the existing 1.0.x app. Keep the old app installed to preserve its settings. Open it with the device's file manager and choose Install. If Android asks, allow that file manager to install apps from this source.
3. Launch **GS Fighter** from the Android app launcher. No terminal, Node.js, server, browser address, or internet connection is needed for the installed game.

Minimum Android version: **8.0 / API 26**. A current Android System WebView is recommended because the game uses modern browser features. This build is universal Java/DEX, without CPU-specific native libraries. It has not been tested on the user's physical Retroid handheld.

The fourteen featured fighters, game music controls, seven effects, Parallax Run, Sprite Workshop, and Sound Workshop are bundled inside the APK. The application's only requested permission is vibration. It does not request internet or broad storage permissions.

## Handheld controls

- A detected native Android gamepad is assigned to Player 1 when that slot has no controller.
- Android stick, hat/D-pad, face-button, shoulder, trigger, Select, and Start events are normalized to the existing browser-standard mapping. The controller editor remains available for adjustments.
- Press **Android Back**, or the **GS MENU** button, for Resume, Fighter select, Parallax Run, Sprite Workshop, Sound Workshop, Controller setup, and Exit.
- Back first pauses an active fight or run. Leaving the app or losing window focus clears held inputs and requests a pause. Resume explicitly when returning.
- Both touchscreen play and physical controls are supported by the integration. Exact physical labels and input modes vary by handheld; use Controller setup to check them on the device.
- The app is locked to landscape, including the workshops. Turning the device does not select portrait mode. Android may terminate the process in the background; that restarts the game on next launch.

## Current gameplay and animation features

- Fresh installs show Static in Blue / Player 1 and Nika in Red / Player 2 (CPU by default). Existing selections remain respected. Changing either fighter saves the pair; returning from a match remembers the pair actually played, and reopening restores it. This is a selection preview, not an automatically launched fight.
- Critical-health camera defaults: enter at 20% health, ease toward a maximum 1.20× scene scale (including the backdrop), and ease out when both fighters are at least 25%. The camera limits its zoom to keep both fighters visible and holds the floor position steady. Pause freezes it, and reduced-motion preferences disable the animated zoom. Existing knockout lead-in slow motion, hit stop and fall timing remain intact.
- Survival recovery defaults: when either fighter first reaches 20% health or below, staying alive gradually restores up to 5% over 3 simulation seconds of maximum health (6 of 120 HP), once per fighter per round. It applies equally to humans and CPU, never revives a KO, and does not trigger at timeout. Pause and finale time scaling affect simulation time normally. If the fighter started below 20%, the 5% reward can leave them below the 25% camera exit threshold; the close view then remains until the threshold is reached or the round ends.
- Setup → Controller & match setup → Cinematic workshop exposes zoom/recovery toggles, trigger/exit thresholds, reward amount, survival duration, zoom strength and reset. Settings persist on this device. These are development controls; public distribution is not part of this build.
- Added exactly two new authored near-apex jump drawings for each of Rokr, Cyon, Major, Sheila, Rayburn, Hen Dog, Mike, Shadow, Tank, Billie, Tye, Akeem and Nika: 26 new drawings total. Static retains her approved 80-pose set; the other thirteen now advertise 72 poses. Existing launch, landing, attack, hit and hop sequences retain their original art. Jump height, gravity, movement, damage and attack speed remain unchanged. Near-apex frames are chosen from vertical velocity, so they work in fights and Parallax Run.
- Jump animation workshop provides autoplay, FPS, frame-step, old/new comparison, per-fighter selection, art reload and pinch/drag preview zoom. Its game toggle restores the previous jump drawings without changing physics. Preview FPS is independent of game speed.
- New artwork was produced using the built-in image-generation tool, with existing rising/apex/falling sprites as identity/style references. Original transparent generated PNGs, lossless WebP runtime atlases, roots/scales and generation prompts are in workshop-assets/jump-apex, jump-apex-frames.js and docs/jump-apex-prompts.json. Sheila's extra-leg generation error was corrected before integration. No generated motion blur was added.
- Rebuild hooks are in patch-development.py, fight-cinema.js, comeback-engine.js, jump-apex-motion.js and the jump workshop files. prepare-assets.py applies the development patch after the previous Android patches. The old baseline deterministic self-test (without optional comeback config) remains ee881250; enabled comeback behavior is separately tested.

## Changes in 1.0.15 · All fourteen HD selection and intro portraits

- Imported the individually redrawn 1024×1536 transparent character portraits from Jerm747-build185, using its preview-portraits.js character-to-file mappings and body bounds. Every featured GS Fighter character now uses these images for the large selection previews and cinematic introductions. The red-side preview and Player 2 intro face inward. Combat sprites, animation atlases and gameplay remain unchanged.
- The APK uses lossless WebP versions whose decoded RGBA pixels match the original PNGs exactly. All fourteen original PNGs, encoded files, source-build paths, hashes and artwork prompts are retained in workshop-assets/portraits and docs/hd-portrait-prompts.json. No new or substitute artwork was generated.
- Both selected portraits preload before the intro. The loader retries failed files, keeps at most six completed decoded portraits, pins the active pair and uses existing portrait/sprite art as a fallback. Cached preview binding avoids a redundant low-resolution swap on return; stale asynchronous selections are cancelled. Retry assets reloads the selected pair.
- Integration is in intro-art.js, intro-art-frames.js and patch-portraits.py. prepare-assets.py applies it after the game and music patches. All fourteen palette orbs, music controls, sound, movement, controller setup and landscape lock are retained.

## Changes in 1.0.14 · Palette orbs for all 14 fighters

- Every featured fighter now uses the approved six-phase V-wave orb in fights and Parallax Run. Static keeps her approved blue-white rendering exactly. Other fighters use colors drawn from their artwork: Rokr gold, Cyon blue, Major green, Sheila red, Rayburn orange, Hen Dog purple, Mike burnt orange, Shadow violet, Tank crimson, Billie yellow-gold, Tye magenta, Akeem teal and Nika gold. Editable palette metadata, outfit references and names are in docs/orb-palettes.json and v-wave-frames.js.
- The bright center, soft trail, exposure flicker and electric impact remain. Both fight slots and CPU opponents pass their own fighter identity to the renderer; runner projectiles and box impacts retain their owner's tint. Reduced motion still disables flight animation and simplifies the impact.
- The original orb atlas is reused. Colored layers preserve the transparent edges and luminance, blend into the stage lighting and are cached. Only four recent scene/palette sets are retained, rather than all fourteen variants; tinted caches use 256-pixel cells for the 108-unit effect. Static retains her existing 512-pixel cached cells.
- Projectile spawn positions, damage, collision ranges, movement and timings are unchanged. Deterministic simulation fingerprint remains ee881250. Existing music, all original marbled covers, controls and landscape lock remain in place.

## Changes in 1.0.13 · Original Jerm747 music widget styling

- Adapted the Get Down music widget to GS Fighter: dark rounded cards, original marbled 747 cover artwork, teal/accent glow, large circular playback control, custom seek bar, one volume slider and mute, shuffle, repeat all/one/off and orange Back to game button at the top. A two-column landscape layout places playback beside the local playlist; narrower portrait browser previews stack it. Touch and controller buttons remain available.
- Add music, persistent local tracks, removal and pause/return behavior are retained. No audio is bundled or fetched from the website. All 60 original Jerm747 marbled covers and original player styling sources are included in workshop-assets/player for future work. Filename-derived cover assignments stay consistent across restarts and removals. No generated replacement art is used.

## Changes in 1.0.12 · Jerm spelling

- Corrected the music widget branding to JERM 747. Jerm is always spelled with a J, including when dictation supplies the other spelling.

## Changes in 1.0.11 · In-game music and a brighter V-wave

- MUSIC opens a standalone local music deck inspired by the Get Down widget: Now Playing, playlist, previous/play/next, native seeking, volume, shuffle, repeat all/one/off and track removal. Use **Add music** to choose multiple audio files from the device or an accessible SD card. Added tracks are copied to private browser storage and restored on reopening; import feedback explicitly identifies any tracks that could only load for the current session. No songs are bundled in this update, and no files are uploaded. Supported codecs depend on Android System WebView. Individual imports are limited to 150 MB.
- Opening music pauses an active fight. Back to game resumes a fight paused by the panel and keeps music playing; a fight that was already paused stays paused. Android backgrounding still pauses audio.
- Static's V-wave retains its 108-unit width, scene tint, 62% saturation, six phases, candle flicker and electric impact. Overall screen opacity increases from 78% to 94%, with a softly masked 72% source-over core layer to give the center more presence without increasing saturation. Cached layers are reused. Other fighters, combat damage, timing, physics and the ee881250 simulation reference are unchanged.
- Rebuild integration lives in game-music.js, game-music.css and patch-music.py. prepare-assets.py applies it to the original browser source along with the other Android patches.

## Changes in 1.0.10 · Short stops and Static HD intro

- Increased normal grounded deceleration to 1800 world units/s² and Duck-slide deceleration to 1600 in fighter mode and Parallax Run. At normal maximum running speed, release/Duck now stop in roughly 0.13–0.17 seconds, with about 13–18 units of glide. Air momentum, acceleration, maximum running speed, attack timings and damage are retained.
- Static now has a dedicated 1024×1536 transparent full-body intro illustration. It is rendered from its high-resolution source during her close-up and two-fighter introduction; Player 2 is mirrored inward. Combat sprites remain in their existing animation atlases. The intro loader retries through GSAssets, and the existing sprite remains available as a fallback if the new artwork cannot load.
- The original generated PNG, body bounds and full built-in image generation prompt are in workshop-assets/intro/ and docs/static-intro-hd-prompt.txt. intro-art.js / intro-art-frames.js provide the reusable intro integration. This first HD intro is for Static only.
- Updated deterministic combat reference: ee881250, verified across 30 FPS, 144 FPS and jittered timing. Intro-to-fight transition, mirroring, source dimensions, short stops, retained airborne velocity and combo timing passed automated checks.

## Changes in 1.0.9 · Blast size

- Static’s blast is 108 world units wide, exactly three times the 36-unit width in 1.0.8. Color, shape, opacity, scene tint, alpha fade, screen blend and impact rendering remain unchanged. Runner box-contact radius scales from 8 to 24 units with the enlarged projectile. Combat damage and motion tuning remain intact.
- The V-wave workshop Game size button now selects 108.

## Changes in 1.0.8 · Fighter momentum and scene integration

- Both human fighter slots now use acceleration, retained air velocity, landing coast, gradual reversals and Duck slides. Block actively brakes, hits stop drift, and arena bounds constrain movement. CPU decision logic retains its previous movement. Runner 2× sprint remains in Parallax Run; fighter mode retains its existing speed cap.
- Wave startup no longer stops horizontal movement. Players can fire while running, retreating or jumping. Fight projectiles inherit shooter momentum; Static's emission point is moved to the forward hand so the smaller core appears beyond her palms. Punch/kick timing, combo buffering, damage and round timers retain the previous tuning.
- Static's orb is one quarter of the previous width: 36 rather than 144 world units. Six cached frame textures apply reduced saturation, a warm sunset tint in fights / daylight tint in the runner, an alpha fade into the tail, 78% opacity and screen blending. This is Canvas 2D compositing, not a new Android GPU shader pipeline. The original transparent atlas is preserved. Color work is cached instead of recomputed per pixel every frame.
- Impact lightning is reduced to half its prior dimensions. Round motes and subtle exposure flicker remain. Runner collisions are narrowed to the smaller Static orb, and the firing height is adjusted to meet ground boxes. The V-wave workshop has a Game size · 36 px button; its large artwork preview remains available for inspection.
- Updated deterministic combat reference: 454f5e7b. Player motion changed, so this differs from 1.0.7; 30 FPS, 144 FPS and jittered render timing still produce the same result within this build.

## Changes in 1.0.7 · V-wave and momentum

- Static's V-wave uses the approved six-frame transparent energy atlas: straight pinched tail, round motes, a lit spherical core and violet aura. The core and motes animate, with gentle candle-like exposure variation. The effect mirrors for either player. A short local lightning burst occurs only when a hit or block succeeds; block intensity is reduced. Reduced-motion mode removes flicker, orbit movement and lightning, keeping a soft impact ring. Candle flicker can also be disabled under Controller & match setup.
- Reusable renderer and frame metadata live in v-wave.js / v-wave-frames.js; the unchanged generated atlas and metadata are in workshop-assets/v-wave/. Only Static uses this effect in fights for this pilot. Missing artwork falls back to the old effect; Retry assets attempts loading again.
- The general Sprite Workshop also starts with Smooth enabled and now supports pinch/wheel zoom plus Reset view. Zoom affects only the preview; exported PNG/GIF dimensions and registration stay intact.
- New V-wave workshop link below the fighter grid. Smooth starts on, with high-quality scaling. Two-finger pinch zooms 1x–4x around the fingers; dragging pans when zoomed, and Reset view fits it again. Mouse wheel and slider alternatives are included. The standalone page also includes lighting/vignette, flicker, colors, FPS, size, aura, speed lines and impact-preview controls. Source art and full prompts are retained.
- Parallax Run has independent horizontal momentum. Releasing direction in midair preserves takeoff speed. Landing carries speed into a coast; holding Duck gives a longer ground slide. Opposite direction brakes before reversing. Pausing freezes momentum and releases held controls; Retry starts at rest. Jump height and gravity retain the existing engine values.
- Runner base speed is 250.1928 units/s, 8% above 1.0.6's 231.66. Hold the new 2× SPEED button, Shift or R2 to accelerate toward 500.3856. Releasing the button eases down instead of snapping to normal speed. The existing 10% faster attack timing is retained.
- Static can fire while running or airborne. Runner projectiles inherit horizontal velocity, stay in world coordinates as the background scrolls, and use swept collisions to destroy low boxes. Box debris, a local energy impact and the existing ground effect play once per box; destroyed boxes cannot bump the player. Floating gates remain duck obstacles. The HUD counts blasted boxes. All runner characters can break boxes; Static displays the new orb.
- Fight damage, ranges, collision rules, timers, combo buffering and the 14-fighter roster remain as in 1.0.6. The deterministic combat fingerprint remains 59c4e76c.

## Changes in 1.0.6

- Static's high kick adds two authored roundhouse intermediates, one rising and one descending. The original apex remains at the hit-contact time. Static now has 80 canonical drawings; all other attack artwork stays intact.
- Punches and kicks play 10% faster. Step, hop and run speeds rise 8%. Every attack deals 75% of its former damage. Wave timing, round timing, hit protection and physics remain unchanged.
- Removed the extra 80 ms punch/kick cooldown. A button press in the last 110 ms can queue one follow-up until full recovery; attacks cannot cancel one another. Inputs clear on pause or menu changes.
- Disabled accidental text selection, image dragging and long-press callouts in game screens while retaining focus feedback and editable workshop fields.
- Static workshop Auto now includes the high kick. Its gallery has ten added drawings. Both atlases, frame registration and generation prompts are included in this kit.

## Changes in 1.0.5 · Static pilot

- Playable selection and opponent rotation now focus on the 14 featured fighters. Removed the Additional fighters toggle. Saved legacy statistics are retained, but extra characters are not offered in this game. Some legacy fallback resources remain bundled; no original browser archive is changed.
- Static has eight new authored in-between drawings: two forward-walk, two forward-run, two backward-walk, one rising-jump and one falling-jump. Her canonical set is now 78 drawings. The other 13 keep their existing 70-pose sets for this pilot.
- Corrected Static’s pose selector so groundedWalk does not override the run and idle states. Forward and backward steps now have distinct four-frame cycles; running has four phases. Gait progression still follows movement distance, preserving simulation speed and attack behavior.
- Faint two-snapshot motion trails support Static's run, fast attacks and jumps. The main sprite stays sharp. Trails respect reduced-motion preferences and can be switched off under Controller & match setup. This is a pilot on Static; other fighters retain their previous rendering.
- Open Controller & match setup below the fighter grid → Static animation workshop. It starts in Auto mode, rotating forward walk, run, backstep and jump after three loops each. Pause, Next frame, FPS, root guides and trail controls remain available. Select one sequence to stay on it. Before/after previews use the same overall cycle duration.
- The workshop gallery exposes all eight new drawings. Source atlas, frame bounds, anchors, generation prompt, runtime integration and preview data are included in this source kit. The atlas was produced with the built-in image generation tool and is copied unchanged; bounds/anchors are metadata. This is a reviewable movement pilot, ready for further pose and timing refinement on the handheld.
- The new atlas is included in workshop-assets/. prepare-assets.py installs it automatically along with static-frames.js, static-motion.js and the workshop page/data. Existing browser assets are still supplied by GS-Fighter-1.0.zip.

## Changes in 1.0.4

- Fighter selection now reads the native left stick independently of combat movement bindings, with mapped directional buttons still supported. Blue and Red selection locks reset synchronously whenever the engine returns to selection, including a rapid intro/fight/back transition that can occur between periodic UI updates.
- Reduced the individual intro close-up from 1.85 to 1.08 screen heights and reduced the two-fighter pullback zoom. This preserves the existing images without inventing resolution.
- First registration pass across all 14 featured fighters: 980 canonical frames, with body-centered horizontal roots, consistent opaque ground contact and matching idle sizes. The source artwork, pose timing, attack ranges and physics are retained. The corrected roots are used by fights and Parallax Run. Editable metadata is in featured-anchors.js; the audit is in docs/animation-anchor-audit.json.
- Short glassy high-pitched navigation chime (1450 Hz fundamental) and lower confirmation chime (880 Hz). The two use decaying bell partials, separate from combat effects. Changing a fighter or returning to selection uses the high ting; confirming or launching uses the lower tone. Both are adjustable/importable/exportable in Sound Workshop and honor effects mute and master volume.
- WORKSHOP-NOTES.md records the requested future visual distinction between Tank and Mike. Their designs stay intact for this release.

## Changes in 1.0.3

- Large APPLY CONTROLS button explicitly saves the selected controller's scheme, publishes the mapping change, releases held input and makes every reader reload it. This also covers the Parallax Run reader.
- The editor keeps draft changes separate from the active scheme. Manual edits and partially completed walkthroughs survive closing and reopening setup, or reloading the app. Only Apply activates them. A failed storage write is reported instead of claiming success.
- The completed walkthrough displays MAPPING COMPLETE — PRESS APPLY. Apply displays CONTROLS APPLIED ✓. An early Stop is labeled separately; it does not falsely claim the walkthrough was completed.
- The live ACTIVE TEST lists actions using the applied scheme. Release held buttons and sticks after applying, test the controls here, then choose Back to game.
- Fixed saved movement loading dropping an accompanying stick binding. Remapping a movement button retains its stick direction; mapping an axis keeps a standard D-pad option where applicable. Mapping a physical control already used elsewhere moves that binding to its new action and updates the displayed scheme.
- The detected starter profile is now a draft choice requiring Apply. It cannot silently overwrite custom assignments during editing.
- Controller changes are reproducible through the Android-owned controller-map.js copied by patch-game.py. The browser ZIP and previous APKs remain unchanged.

## Configure your controller

1. Open GS MENU → Controller setup, then Gamepad / Set up buttons for the connected controller.
2. Use Classic Auto or Six-attack Auto, or select an individual game action to map it. Movement & menu buttons exposes stick/D-pad directions, Jump, Start and Music.
3. When the walkthrough finishes, look for MAPPING COMPLETE — PRESS APPLY. Stopping early retains captured edits, but the previous active scheme stays in use.
4. Press the large APPLY CONTROLS button. Look for CONTROLS APPLIED ✓, release the pad, then press buttons and move the stick to inspect ACTIVE TEST.
5. Choose Back to game. The scheme remains saved for that controller across page changes and app launches. Jump is also the menu-confirm action; Kick / Mid kick is menu-back.

## Changes in 1.0.2

- Native window and WebView start black. A three-second black opening hides all game UI and blocks selection input, then the GS Fighter logo fades in for 2.6 seconds before fighter previews appear. If art is still loading, the logo remains; a failed load offers Retry rather than exposing an incomplete selection screen.
- Player 2's selection portraits, including alternate outfits, are mirrored to face Player 1. Combat and introduction facing retain the existing engine logic.
- The arena now fills the entire viewport; the old eight-pixel reserve is removed. Top controls are translucent over the scene, with full opacity on focus or touch. Selection controls remain easy to read.
- Larger, bolder timer and score, plus larger cinematic score count-up text. YOU WON / YOU LOST use the same italic arcade treatment as FIGHT. In two-human matches, the headline identifies PLAYER 1 / PLAYER 2 instead.
- Set-list UI and completion wording are removed. Finish round advances an intermediate round, or returns to the logo at match completion. The current first-to-two rules remain intact.
- A match loss starts a ten-second return-to-title countdown. Play again can start a new match immediately; Finish round returns immediately. The countdown stops once the result is left and pauses while the page is hidden. After the title, both selections are unlocked again.
- New rising jump effect plays on the engine's actual takeoff event in fights and Parallax Run. A layered low-frequency kachoom plays on landing, with a stronger knockdown impact. Tiny automatic travel hops do not trigger the landing boom. Both sounds support the existing effects mute, master level, replacement clips, synthesis controls and WAV export. The Sound Workshop now has five voices.
- The portable browser ZIP and delivered 1.0.1 APK/source archive remain unchanged. The build is a compatible update using the retained workshop signing key.

## Changes in 1.0.1

- Fixed a short-landscape CSS rule that left the fighter selection screen over the live fight after the intro. Hidden overlays now stay hidden.
- Arcade is the default full-screen presentation. Removed the old Arcade / Fullscreen / Close toolbar; a persistent START button confirms selection, begins the matchup, skips the intro, and pauses/resumes a fight.
- Larger fighter preview and featured fourteen-fighter grid lead the selection screen. Additional fighters remain available. Controller assignment, random choices and match setup are below the roster under Controller & match setup.
- Easy, Medium, Hard and the Scores menu are hidden. Their underlying logic is retained. The fight HUD uses Arcade rather than a difficulty label.
- Left stick moves Blue. Right stick can preview Red at any time. A confirms Blue first, then Red; both locks reveal a large branded START screen. B unlocks Red, then Blue.
- With one stick, left moves Blue first and Red after Blue is confirmed. With two physical controllers, the second pad previews Red and its A confirms Red after Blue, enabling human Player 2. With one controller Red remains CPU in the fight. A single controller's right stick is for selecting Red, not controlling both fighters during combat.
- Android right-stick inputs support both Z/RZ and RX/RY device axis conventions.
- Landscape orientation is fixed for every page.

## Workshop files and SD cards

Image frames, sprite sheets, saved animation projects, music, and replacement effects use Android's document picker. It can show internal storage and SD cards exposed by the handheld's file provider.

PNG sheets, animated GIFs, JSON frame maps/projects, and synthesized WAV exports open Android's **Save as** dialog. Choose the destination yourself. Exports are streamed in chunks into a temporary cache file before the document picker opens; the temporary file is removed after saving or cancelling. Individual exports are limited to 120 MiB, and editable projects to the existing browser workshop's 100 MiB import limit.

No file-manager access to the application's private directory is needed. Browser settings and imported sound clips live in the app's private WebView storage. Music-file selections are session-only and need selecting again after a reload. Export editable sprite projects before uninstalling; uninstalling removes app-private data.

## Rebuild from this source kit

This source kit is intentionally small: it contains the Android wrapper, Android-only integration scripts, launcher resources, Gradle wrapper and workshop signing key. Reuse the artwork and game from the previously supplied **GS-Fighter-1.0.zip**; the APK already includes those assets, so they do not need to be downloaded again to install it.

1. Install Android Studio with JDK 17, Android SDK Platform 35, and SDK Build-Tools 34.0.0 (or allow Gradle to install build tools).
2. Extract GS-Fighter-1.0.zip next to this project.
3. Run:

```sh
python3 prepare-assets.py ../GS-Fighter-1.0/public
./gradlew assembleRelease lintRelease
```

On Windows use `python` and `gradlew.bat`. Android Studio configures `local.properties`; for a command-line setup add `sdk.dir=/your/android/sdk` to that file.

The output is `app/build/outputs/apk/release/app-release.apk`.

`prepare-assets.py` copies the browser source into Android assets, injects `android.js`/`android.css`, applies the reproducible Android-only selection and engine changes in `patch-game.py` plus `android-fighter.js`/`android-fighter.css` and `android-presentation.js`/`android-presentation.css`, adds the reusable V-wave effect and workshop, applies patch-runner.py for momentum and destructible boxes, adds an audio suspension hook, and regenerates the local asset manifest. It does not modify the supplied browser project. The input public folder must be the complete GS Fighter package, not the earlier incomplete Jerm747 source ZIP.

The included `signing/workshop.jks` is a development/workshop signing key, alias `gsfighter`, store/key passwords `android`. Preserve it to build compatible updates for this app ID (`com.jerm747.gsfighter`). It is not a production publishing key. For public distribution, use your own protected signing arrangement. Increase `versionCode` for subsequent APK updates.

## Implementation

- Android Activity + WebView, Java 17 source, Android Gradle Plugin 8.7.3, Gradle 8.9.
- AndroidX WebKit 1.12.1 serves the bundled app under `https://appassets.androidplatform.net/` using WebViewAssetLoader. Root asset paths are retained; no local HTTP server runs on the device.
- Navigation and resource requests are restricted to bundled content; `file://` and universal file access are disabled. The native bridge is exposed only inside this local app.
- Native controller snapshots feed `navigator.getGamepads()` so the original game engine and control mapping remain intact.
- A file chooser handles `<input type=file>`; exports use ACTION_CREATE_DOCUMENT and do not need broad storage permission.
- Pause/resume integration stops held controller inputs and pauses music/effects when the activity loses focus or leaves the foreground.

## Verification and limits

The release APK compiled, passed Android lint with no errors, and its APK v2 signature was verified. Lint has non-blocking warnings about the pinned WebKit version, deliberately enabled JavaScript, fixed landscape orientation, and manifest attributes used by newer Android versions.

Version 1.0.5 checks the 14-only selection, all eight new RGBA frames, 78-pose metadata, distinct gait selectors, real native-pad running through new intermediates, Auto preview cycling, all four before/after sequences, pause/frame-step controls, and Parallax Run integration. It also reruns the 15 controller/selection regression checks. No missing assets or uncaught errors were observed.

Version 1.0.4 checks all four raw-stick directions across repeated selection returns with incomplete combat directional mappings; checks all 980 anchor records, all 980 advertised sequence poses, and corrected metadata in Parallax Run; and checks distinct selection/confirmation audio. Engine checks exercise seven attacks per featured fighter (98 hits) at fixed spacing without changing the attacker root. Representative standing, walking, attack, crouch and reaction frames are inspected on common root/ground guides. This registration pass does not replace a future drawing/limb-continuity pass.

Version 1.0.3 checks remap actual editor controls, apply them, verify custom Mid punch and Jump in a live fight, verify both stick and digital movement, reload the page, retain stopped walkthrough edits, and finish the entire 13-step Classic wizard with explicit completion and application messages. Native pad snapshots are simulated; physical handheld firmware still needs checking.

Version 1.0.2 checks cover an all-black opening, blocked startup input, logo-to-selection flow, mirrored Red portraits, full-height arena, larger HUD type, round win/loss screens, Finish round advancement, match results and timed return through the title. Test-only HTTP instrumentation accelerates outcome setup; no outcome-forcing methods ship in the APK. Jump, landing and knockdown events and synthesized WAV exports are checked.

Version 1.0.1 Chromium checks verified visible combat after natural and skipped intros, independent selection sticks, sequential single-stick selection, gated confirmation, second-controller Player 2 movement, persistent Start pause/resume, fourteen featured fighters and hidden difficulty/scores. No missing assets or uncaught errors were observed. These checks simulate native pad snapshots; they do not emulate Android orientation enforcement.

Baseline automated Chromium integration checks exercised the Android JavaScript bridge with simulated native gamepad data: Player 1 assignment, jump events, pause/resume, and chunked GIF/WAV exports passed with no missing assets or uncaught errors. The exported media was independently decoded. Every bundled game asset was checked against the packaged SHA256 manifest.

Those tests do not substitute for running on a physical Android device. Device WebView behavior, the Android document provider, controller firmware/layout, performance, and vibration require the handheld check. There was no Android emulator or Retroid hardware attached during this build.
