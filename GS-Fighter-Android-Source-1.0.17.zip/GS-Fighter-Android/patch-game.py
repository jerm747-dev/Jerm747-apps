"""Apply the Android 1.0.10 fighter UI integration to a fresh browser asset copy."""
from pathlib import Path

def patch(target: Path):
    p=target/'index.html';h=p.read_text()
    h=h.replace('<script src="/android.js"></script>','<script src="/android.js"></script><link rel="stylesheet" href="/android-fighter.css">',1)
    boot_head="""<script>document.documentElement.classList.add('gs-boot');window.GSBootStarted=performance.now();</script><style>html.gs-boot,html.gs-boot body{background:#000!important}html.gs-boot body>:not(#gs-boot){visibility:hidden!important}#gs-boot{position:fixed;inset:0;z-index:10000;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#ffe4ac;text-align:center}#gs-boot img{width:min(76vw,750px);max-height:65vh;object-fit:contain;opacity:0}#gs-boot.gs-logo img{opacity:1;transition:opacity .65s}#gs-boot p{margin:0;font:800 12px system-ui;letter-spacing:.22em;opacity:0}#gs-boot.gs-logo p{opacity:1}#gs-boot button{display:none}#gs-boot.gs-boot-error button{display:block}#gs-boot.gs-boot-error p{opacity:1}</style>"""
    h=h.replace('<head>','<head>'+boot_head,1)
    h=h.replace('<body>','<body><section id="gs-boot" aria-label="GS Fighter opening"><img src="/brand/gs-fighter.png" alt="GS Fighter"><p></p><button onclick="location.reload()">Retry loading</button></section>',1)
    h=h.replace('<link rel="stylesheet" href="/android-fighter.css">','<link rel="stylesheet" href="/android-fighter.css"><link rel="stylesheet" href="/android-presentation.css">',1)
    h=h.replace('</body>','<script src="/android-fighter.js"></script><script src="/android-presentation.js"></script></body>')
    h=h.replace("e.key==='Escape'&&!window.Jerm747Presentation", "e.key==='Escape'&&!window.GSAndroid&&!window.Jerm747Presentation")
    h=h.replace('function ovExit(fromSystem){','function ovExit(fromSystem){if(window.GSAndroid)return;')
    h=h.replace('function ovFull(want){','function ovFull(want){if(window.GSAndroid)return;')
    h=h.replace('function hud(){const state=battle;',"function hud(){document.documentElement.classList.toggle('gs-lobby',screen==='lobby');const state=battle;")
    # Keep the existing difficulty logic while removing its label from the fight HUD.
    h=h.replace("${ARCADE_DIFFICULTIES[run.difficulty].label} · Opponent", "Arcade · Opponent")
    h=h.replace('Choose fighter / scores','Choose fighters')
    anchor_tag='<script src="/assets/replacement-slots-v158.js?v=158"></script>'
    assert anchor_tag in h
    h=h.replace(anchor_tag,anchor_tag+'<script src="/featured-anchors.js"></script><script src="/static-frames.js"></script><script src="/static-motion.js"></script>')
    h=h.replace('scale=height/sheet.maxH,width=bounds.w*scale','scale=height/sheet.maxH*(bounds.poseScale||1),width=bounds.w*scale')
    h=h.replace("selection();hud();$('start').focus();","selection();hud();window.GSAndroidSelect?.reset();if(!document.documentElement.classList.contains('gs-boot'))window.GSSound?.play('navigate');$('start').focus();")
    h=h.replace('ids=[...window.GS_FEATURED,...ARCADE_FIGHTERS.filter(id=>!window.GS_FEATURED.includes(id))]','ids=[...window.GS_FEATURED]')
    start=h.index('const trail=actor.renderTrail,now=battle.t,fast=');end=h.index('paintSprite(ctx,sheet,frame,',h.index('actor.renderTrail={x:actor.x',start))
    old=h[start:end]
    h=h[:start]+"if(id==='mama-love'&&window.GSStaticMotionTrail){window.GSStaticMotionTrail.draw(ctx,actor,{sheet,frame,bounds,scale,width,h},battle.t,reduce,paintSprite);}else{"+old+"}"+h[end:]
    # The reusable renderer renders the approved orb with each featured fighter palette.
    h=h.replace('<script src="/static-motion.js"></script>', '<script src="/static-motion.js"></script><script src="/v-wave-frames.js"></script><script src="/v-wave.js"></script><script src="/intro-art-frames.js"></script><script src="/intro-art.js"></script>')
    h=h.replace('paint(ctx,id,x,y,height,facing){const sheet=', "paint(ctx,id,x,y,height,facing){if(window.GSIntroArt?.paint(ctx,id,x,y,height,facing))return;const sheet=")
    h=h.replace('window.GSVWave?.load(true);for(const id', 'window.GSVWave?.load(true);window.GSIntroArt?.load();for(const id')
    h=h.replace('function drawWave(ctx,wave){',"function drawWave(ctx,wave){const emitter=wave.owner==='player'?run.member:battle.opponent;if(window.GSVWave?.active(emitter)&&window.GSVWave.flight(ctx,wave,battle.t,reduce,{fighter:emitter}))return;")
    h=h.replace('for(const e of battle.effects){ctx.save();',"for(const e of battle.effects){if(e.kind==='v-wave-impact'&&window.GSVWave){window.GSVWave.impact(ctx,e,reduce);continue;}ctx.save();")
    h=h.replace('window.GSFighter={state:', 'window.GSFighter={state:')
    h=h.replace("reloadAssets:()=>{for(const id","reloadAssets:()=>{window.GSVWave?.load(true);for(const id")
    h=h.replace('arcadeResetMovement(actor);actor.movePhase=', 'actor.queuedAttack=null;arcadeResetMovement(actor);actor.movePhase=')
    # Use synchronous engine hooks, avoiding a flash of legacy result copy.
    h=h.replace("hud();$('next-round').focus();", "hud();window.GSArcadePresentation?.round();$('next-round').focus();")
    h=h.replace("hud();$('again').focus();", "hud();window.GSArcadePresentation?.result();$('again').focus();")
    h=h.replace("$('timer').textContent=`${Math.ceil(state.timeLeft)}s`", "$('timer').textContent=String(Math.ceil(state.timeLeft))")
    h=h.replace('Set list complete','Finish round')
    needle='window.Jerm747GameControls={selectFighter,'  
    assert needle in h,'Game control integration point changed'
    api="""window.GSSelectionEngine={
 state:()=>({screen,paused,chosen,red:opponentChoice,active:playerSeats.active,human:[...playerSeats.human],mode:run.mode,outcome:run.outcome,wins:run.wins,losses:run.losses,score:run.score,assetReady,artTotal,playerX:battle.player.x,redX:battle.boss.x,playerY:battle.player.y,hp:battle.hp,bossHp:battle.bossHp}),
 activate:i=>{if(screen==='lobby'&&[0,1].includes(i)){playerSeats.active=i;selection();}},
 move:(i,direction)=>{if(screen!=='lobby')return false;const buttons=[...fighterButtons.values()].map(v=>v.button).filter(b=>!b.hidden&&b.getClientRects().length);const b=window.Jerm747FighterSelect.next(buttons,i?opponentChoice:chosen,direction);return b?pickFighter(i,b.dataset.fighter):false;},
 pick:(i,id)=>pickFighter(i,id),launch:()=>restart(),arcade:()=>ovEnter(),lobby:()=>lobby(),assign:(index,i)=>slotUI.assign(index,i)
};
"""
    h=h.replace(needle,api+needle);p.write_text(h)
    p=target/'gs-shell.js';h=p.read_text();h=h.replace("const splash=document.createElement('div');", "if(!window.GSAndroid){const splash=document.createElement('div');").replace("setTimeout(()=>splash.remove(),2500);", "setTimeout(()=>splash.remove(),2500);}");p.write_text(h)
    p=target/'assets/round-finale.js';h=p.read_text()
    h=h.replace("['ROUND WON'", "['YOU WON'").replace("['ROUND COMPLETE'", "['YOU LOST'").replace("['EVEN VOICES'", "['DRAW'")
    h=h.replace("Math.min(width-24,520)","Math.min(width-24,650)").replace("Math.min(height*.48,190)","Math.min(height*.62,250)")
    h=h.replace("900 ${Math.max(19,Math.min(38,width*.048))}px system-ui", "900 italic ${Math.max(32,Math.min(68,width*.082))}px Impact,system-ui")
    h=h.replace("900 ${Math.max(20,Math.min(34,width*.04))}px system-ui", "900 italic ${Math.max(28,Math.min(48,width*.058))}px Impact,system-ui")
    p.write_text(h)
    p=target/'assets/match-intro.js';h=p.read_text()
    # A modest close-up instead of an almost two-screen-high sprite.
    h=h.replace('h*(.92-1.85+1.01*p.pan),h*1.85','h*(.92-1.08+.16*p.pan),h*1.08')
    h=h.replace('1.22-.22*ease','1.10-.10*ease');p.write_text(h)
    p=target/'gs-sound.js';h=p.read_text()
    h=h.replace("ground:{pitch:48,duration:.28,volume:.7,tone:.8}","ground:{pitch:38,duration:.52,volume:.85,tone:.7},jump:{pitch:260,duration:.18,volume:.42,tone:.12}")
    h=h.replace("jump:{pitch:260,duration:.18,volume:.42,tone:.12}","jump:{pitch:260,duration:.18,volume:.42,tone:.12},navigate:{pitch:1450,duration:.065,volume:.26,tone:.05},confirm:{pitch:880,duration:.12,volume:.34,tone:.05}")
    h=h.replace("const freq=p.pitch*(kind==='wave'?1.7-1.2*x:1.6-1.3*x)","const freq=p.pitch*(kind==='jump'?.8+2.2*x:kind==='wave'?1.7-1.2*x:1.6-1.3*x)")
    h=h.replace("data[i]=(tonal*(1-p.tone*.65)+noise*p.tone)*env*p.volume;", "data[i]=kind==='ground'?(Math.sin(phase)*.75*Math.exp(-3*x)+noise*p.tone*1.6*Math.exp(-9*x)+Math.sin(phase*2.4)*.2*Math.exp(-6*x))*Math.min(1,t/.002)*(1-x)*p.volume:(tonal*(1-p.tone*.65)+noise*p.tone)*env*p.volume;")
    h=h.replace('}return data;}',"if(kind==='ground')data[i]=Math.tanh(data[i])* .9;if(kind==='navigate'||kind==='confirm'){const gate=kind==='confirm'&&x>.42?.88:1;const bell=Math.sin(2*Math.PI*p.pitch*t)*Math.exp(-8*x)+.33*Math.sin(2*Math.PI*p.pitch*2.76*t)*Math.exp(-18*x)+.16*Math.sin(2*Math.PI*p.pitch*4.13*t)*Math.exp(-26*x);data[i]=bell*p.volume*Math.min(1,t/.0015)*gate;}}return data;}")
    h=h.replace("else if(e.type==='land'||e.type==='knockdown')play('ground');", "else if(e.type==='jump')play('jump');else if(e.type==='knockdown')play('ground',{impact:1.3});else if(e.type==='land'&&!e.hop)play('ground',{impact:.85});")
    h=h.replace("{preview=false}={}","{preview=false,impact=1}={}")
    h=h.replace("g.gain.value=custom.has(kind)?settings.sounds[kind].volume:1;", "g.gain.value=(custom.has(kind)?settings.sounds[kind].volume:1)*Math.max(.2,Math.min(1.3,impact));")
    h=h.replace('Four percussive voices.','Seven arcade voices, including selection chimes, jump and ground impact.')
    h=h.replace("ground:'Ground impact'", "ground:'Ground impact · Kachoom',jump:'Jump',navigate:'Fighter select · Ting',confirm:'Confirm fighter · Lower chime'")
    p.write_text(h)
    p=target/'assets/engine-core.js';h=p.read_text()
    h=h.replace("{type:'land',target:actor===p?'player':'boss'}", "{type:'land',target:actor===p?'player':'boss',hop:hopped}")
    h=h.replace("k.elapsed+=dt;b.t+=dt;", "k.elapsed+=dt;if(k.elapsed-dt<.8&&k.elapsed>=.8)b.events.push({type:'knockdown',target:k.actor});b.t+=dt;")
    p.write_text(h)
    p=target/'assets/engine-core.js';h=p.read_text()
    tuning="for(const spec of Object.values(CATALOG_MOVES)){spec.damage*=.75;if(spec.kind==='punch'||spec.kind==='kick')spec.duration/=1.10;}\n"
    h=h.replace('function catalogMemberColor',tuning+'function catalogMemberColor',1)
    assert tuning in h,'Move tuning insertion failed'
    h=h.replace('step:75,hop:132,run:214.5','step:81,hop:142.56,run:231.66')
    h=h.replace('spec.duration+.08','spec.duration+(spec.kind==="wave"?.08:0)')
    h=h.replace("if(run.mode!=='fight'||b.readyTime>0||!spec||a.cooldown>0","if(run.mode!=='fight'||b.readyTime>0||!spec||a.attack||a.cooldown>0")
    h=h.replace("ARCADE_SYNC_REFERENCE='d0241921'","ARCADE_SYNC_REFERENCE='ee881250'")
    # A follow-up input in the final 110 ms is kept until full recovery. No cancelling.
    old="if(run.human1&&input.attack){arcadeAttack(run,input.attack);input.attack=null;}if(run.human2&&input.player2?.attack){arcadeAttack(run,input.player2.attack,true);input.player2.attack=null;}"
    new="""for(const [actor,state,human,enemy]of [[p,input,run.human1,false],[a,input.player2,run.human2,true]]){if(!state||!human)continue;if(state.attack){if(!arcadeAttack(run,state.attack,enemy)&&actor.attack&&actor.cooldown<=.11&&!state.block&&!state.duck&&actor.hitAge<0)actor.queuedAttack={move:state.attack,until:b.t+.12};state.attack=null;}if(actor.queuedAttack){const q=actor.queuedAttack;if(b.t>q.until||actor.hitAge>=0||state.block||state.duck){actor.queuedAttack=null;}else if(!actor.attack&&actor.cooldown<=0){arcadeAttack(run,q.move,enemy);actor.queuedAttack=null;}}}"""
    assert old in h;h=h.replace(old,new)
    old="arcadeImpact(run,wave.owner==='player'?'boss':'player',wave.damage);wave.life=0;"
    new="const struck=arcadeImpact(run,wave.owner==='player'?'boss':'player',wave.damage);if(struck)b.effects.push({kind:'v-wave-impact',fighter:wave.owner==='player'?run.member:b.opponent,x:target.x,y:wave.y,life:.28,guarded:target.guard&&target.y>=-.5});wave.life=0;"
    assert old in h;h=h.replace(old,new)
    h=h.replace('x:a.x+attack.facing*35,y:268+a.y,vx:attack.facing*((enemy?!run.human2:!run.human1)?350:460)', "x:a.x+attack.facing*((enemy?b.opponent:run.member)==='mama-love'?75:35),y:268+a.y,vx:attack.facing*((enemy?!run.human2:!run.human1)?350:460)+(a.momentumVx||0)")
    # Player momentum is inline in the engine so every browser and native reader shares it.
    helper=Path(__file__).with_name('fighter-momentum.js').read_text()
    h=h.replace('function arcadeHuman(p,a,input,dt){',helper+'\nfunction arcadeHuman(p,a,input,dt){',1)
    start=h.index(" if(p.guard){p.action='block';",h.index('function arcadeHuman('));end=h.index(' if(input.jump&&',start)
    h=h[:start]+' arcadeFighterMomentum(p,a,input,dt,movement,guardRetreat);\n'+h[end:]
    p.write_text(h)
    p=target/'assets/arcade-motion.js';h=p.read_text().replace('[2,4,6,9,12,16]','[2,4,6,8,9,12,16]').replace("'reactions-a','reactions-b'","'reactions-a','reactions-b','intermediates','roundhouse'");p.write_text(h)
    p=target/'gs-shell.js';h=p.read_text().replace("grid.after(toggle);", "grid.after(toggle);if(!cards.some(b=>!featured.includes(b.dataset.fighter)))toggle.hidden=true;");p.write_text(h)
    p=target/'runner.js';h=p.read_text();h=h.replace('factor=150/(window.Jerm747FighterSet?.(id)?.referenceHeight||baseSheet.maxH)', 'factor=150/(window.Jerm747FighterSet?.(id)?.referenceHeight||baseSheet.maxH)*(f.poseScale||1)');p.write_text(h)
    p=target/'runner.html';h=p.read_text();tag='<script src="/runner.js"></script>';assert tag in h;h=h.replace(tag,'<script src="/featured-anchors.js"></script><script src="/static-frames.js"></script><script src="/static-motion.js"></script>'+tag);p.write_text(h)
    import shutil
    shutil.copyfile(Path(__file__).with_name('featured-anchors.js'),target/'featured-anchors.js')
    for name in ['static-frames.js','static-motion.js','static-workshop.html','static-workshop-data.json']:
        shutil.copyfile(Path(__file__).with_name(name),target/name)
    shutil.copyfile(Path(__file__).with_name('workshop-assets')/'static-intermediates.png',target/'static-intermediates.png')
    shutil.copyfile(Path(__file__).with_name('workshop-assets')/'static-roundhouse.png',target/'static-roundhouse.png')
    for name in ['intro-art.js','intro-art-frames.js','v-wave.js','v-wave-frames.js','runner-momentum.js','v-wave-workshop.html']:
        shutil.copyfile(Path(__file__).with_name(name),target/name)
    shutil.copyfile(Path(__file__).with_name('workshop-assets')/'v-wave'/'v-wave-flight.png',target/'v-wave-flight.png')
    shutil.copyfile(Path(__file__).with_name('workshop-assets')/'intro'/'static-intro-hd.png',target/'static-intro-hd.png')
    runpy=__import__('runpy');runpy.run_path(str(Path(__file__).with_name('patch-runner.py')))['patch'](target)
    shutil.copyfile(Path(__file__).with_name('preview-zoom.js'),target/'preview-zoom.js')
    p=target/'workshop.html';h=p.read_text().replace('<input id="smooth" type="checkbox">','<input id="smooth" type="checkbox" checked>').replace('</head>','<script src="/preview-zoom.js"></script></head>');p.write_text(h)
    p=target/'workshop.js';h=p.read_text();h=h.replace('context.imageSmoothingEnabled=', 'context.imageSmoothingQuality="high";context.imageSmoothingEnabled=')
    h=h.replace('function paint(){ctx.clearRect(0,0,512,512);', 'function paint(){ctx.clearRect(0,0,512,512);ctx.save();previewZoom.transform(ctx);')
    h=h.replace("drawFrame(ctx,frames[current],512,512);", "drawFrame(ctx,frames[current],512,512);ctx.restore();")
    h=h.replace('render();window.GSWorkshop=', 'render();window.GSWorkshop=')
    h=h.replace('function paint(){', 'const previewZoom=window.GSPreviewZoom.attach(canvas,()=>paint());window.GSWorkshopZoom=previewZoom;function paint(){')
    p.write_text(h)
    shutil.copyfile(Path(__file__).with_name('controller-map.js'),target/'assets/gamepad-map.js')
    p=target/'assets/game-console.js';h=p.read_text()
    h=h.replace("else if(c.screen==='lobby')$('start')?.click();","else if(c.screen==='lobby'){if(window.GSAndroidSelect)window.GSAndroidSelect.start();else $('start')?.click();}")
    h=h.replace("const devices=api.gamepadDevices?.();let data;","let devices=api.gamepadDevices?.();if(api.context().screen==='lobby'&&window.GSAndroidSelect)devices=window.GSAndroidSelect.devices(devices);let data;")
    h=h.replace("if(quick>=0&&api.context().screen==='lobby'&&api.justPlay)","if(quick>=0&&api.context().screen==='lobby'&&api.justPlay&&!window.GSAndroidSelect)")
    a="if(c.screen==='lobby'&&!musicOpen&&!helpOpen&&api.selectFighter){"
    assert a in h,'Lobby controller route changed'
    h=h.replace(a,a+"if(window.GSAndroidSelect){window.GSAndroidSelect.poll(data,data2,timestamp);}else{")
    h=h.replace("selectOnGrid(data2,1,timestamp);}}else{resetGridMoves();","selectOnGrid(data2,1,timestamp);}}}else{resetGridMoves();")
    h=h.replace("if(lost){const c=api.context();", "if(window.GSArcadePresentation?.blocked()||document.documentElement.classList.contains('gs-boot')){api.pad({});api.pad2?.({});update();return;}if(lost){const c=api.context();")
    p.write_text(h)

if __name__=='__main__':
    import sys
    patch(Path(sys.argv[1]))
