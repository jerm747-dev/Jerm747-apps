# GS Fighter workshop notes

- Character design: Tank and Mike currently read too similarly. Give them more distinct silhouettes, faces, outfit details and movement personalities in a later art pass. Keep the current artwork for this build, as requested.
- Animation pass 1.0.4: reviewed 70 canonical poses for each of the 14 featured fighters (980 frames). Replaced inconsistent horizontal roots using a torso-weighted silhouette center; aligned opaque ground contact and normalized the two idle drawing sizes to each fighter’s standing reference. Walk/run stride, attack extension, jumps, recoil and the twelve-frame falls remain intact. Engine position and attack ranges are unchanged; the artwork is registered consistently around that position. Anchor metadata is editable in featured-anchors.js; audit correction magnitudes are in docs/animation-anchor-audit.json.
- This is a registration pass over the existing art, not a redraw. Follow-up visual polish can refine pose-specific lean, limb continuity and character distinction after handheld testing.

- Static pilot 1.0.5: eight authored intermediates are integrated. Test forward walk, run, backstep and both jump directions in the Auto before/after preview. Review leg alternation, hair continuity and body scale before adopting this pattern for the other 13. Pilot poses remain editable through metadata and can be replaced individually.
