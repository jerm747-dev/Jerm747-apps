"""Default matchup, optional comeback rules/camera and new jump intermediates."""
from pathlib import Path
import shutil
def patch(target):
 root=Path(__file__).parent
 for n in ['fight-cinema.js','jump-apex-frames.js','jump-apex-motion.js','jump-workshop.html','jump-workshop.js','jump-workshop-data.json','runner.js','runner-picker.js','runner-picker.css']:
  shutil.copyfile(root/n,target/n)
 dest=target/'jump-apex';dest.mkdir(exist_ok=True)
 for p in (root/'workshop-assets/jump-apex').glob('*.webp'):shutil.copyfile(p,dest/p.name)
 p=target/'index.html';h=p.read_text().replace("let opponentChoice='pg'", "let opponentChoice='nitabug'")
 h=h.replace('<script src="/static-motion.js"></script>', '<script src="/static-motion.js"></script><script src="/jump-apex-frames.js"></script><script src="/jump-apex-motion.js"></script><script src="/fight-cinema.js"></script>')
 h=h.replace("function lobby(){if(!justPlay.starting)", "function lobby(){if(screen!=='lobby'&&ids.includes(run.member)&&ids.includes(battle.opponent)){chosen=run.member;opponentChoice=battle.opponent;window.Jerm747SquadChoice?.set(chosen);try{localStorage.setItem('gs-fighter.player-fighters',JSON.stringify([chosen,opponentChoice]))}catch{}}if(!justPlay.starting)")
 # Apply camera only to arena canvas. Intro camera, controls and HUD remain independent.
 old="scale=r.height>r.width?w/span:Math.min(w/span,h/510),viewWidth=w/scale,center="
 new="baseScale=r.height>r.width?w/span:Math.min(w/span,h/510),camera=window.GSFightCinema.camera(battle,w,h,baseScale),scale=camera.scale,viewWidth=w/scale,center="
 assert old in h;h=h.replace(old,new,1)
 h=h.replace("left=viewWidth>=900?(900-viewWidth)/2:Math.max(0,Math.min(900-viewWidth,center-viewWidth/2)),top=h/scale-450;", "left=camera.left,top=camera.top;",1)
 h=h.replace("finale.draw(ctx,run,$('arena').width,$('arena').height);", "finale.draw(ctx,run,$('arena').width,$('arena').height);window.GSFightCinema.hud(ctx,run,$('arena').width,$('arena').height);")
 h=h.replace("previous=timestamp;if(!onlineActive&&screen==='fight'", "previous=timestamp;window.GSFightCinema.update(run,dt,paused,screen==='fight');if(!onlineActive&&screen==='fight'")
 h=h.replace("run.cinematicEnemyDamage=arcadeCfg(run).damage;", "run.comebackConfig=window.GSFightCinema.get();run.cinematicEnemyDamage=arcadeCfg(run).damage;")
 h=h.replace('ctx.worldTop=-top;', 'ctx.worldBackdrop=camera.backdrop;ctx.worldTop=-top;',1)
 h=h.replace('ctx.drawImage(images.arena,ctx.worldLeft||0,Math.min(0,ctx.worldTop||0),ctx.worldWidth||900,450-Math.min(0,ctx.worldTop||0))', 'ctx.drawImage(images.arena,ctx.worldBackdrop.x,ctx.worldBackdrop.y,ctx.worldBackdrop.w,ctx.worldBackdrop.h)')
 p.write_text(h)
 p=target/'assets/engine-core.js';h=p.read_text();helper=(root/'comeback-engine.js').read_text();h=h.replace('function arcadeStep(run,input,dt){',helper+'\nfunction arcadeStep(run,input,dt){',1)
 old="b.projectiles=b.projectiles.filter(w=>w.life>0&&w.x>-80&&w.x<1000);if(b.hp<=0"
 assert old in h;h=h.replace(old,"b.projectiles=b.projectiles.filter(w=>w.life>0&&w.x>-80&&w.x<1000);arcadeComebackStep(run,dt);if(b.hp<=0",1)
 h=h.replace('module.exports={ARCADE_SYNC_REFERENCE,','module.exports={arcadeComebackStep,ARCADE_SYNC_REFERENCE,');p.write_text(h)
 p=target/'assets/arcade-motion.js';h=p.read_text().replace("'intermediates','roundhouse'", "'intermediates','roundhouse','jump-apex'");p.write_text(h)
 p=target/'runner.html';h=p.read_text().replace('<script src="/static-motion.js"></script>', '<script src="/static-motion.js"></script><script src="/jump-apex-frames.js"></script><script src="/jump-apex-motion.js"></script>');h=h.replace('</head>', '<link rel="stylesheet" href="/runner-picker.css"></head>').replace('<script src="/runner.js"></script>', '<script src="/runner.js"></script><script src="/runner-picker.js"></script>')
 h=h.replace('<select id="runner-fighter"', '<button id="choose-runner">Choose fighter</button><select hidden id="runner-fighter"')
 h=h.replace('<button data-action="pMid">', '<button data-action="block">BLOCK <small>F / L1</small></button><button data-action="kHigh">KICK <small>C / mapped pad</small></button><button data-action="pMid">')
 p.write_text(h)
 p=target/'android-fighter.css';h=p.read_text();rule='\n.gs-cinema-settings{display:grid;gap:12px;margin:18px 0;padding:16px;border:1px solid #526987;border-radius:12px}.gs-cinema-settings label{display:flex;align-items:center;gap:10px;font-size:13px}.gs-cinema-settings input[type=range]{flex:1;min-width:90px}.gs-cinema-settings output{min-width:32px}.gs-cinema-settings p{font-size:12px;color:#b8cadf}\n';p.write_text(h+(rule if rule not in h else ""))
