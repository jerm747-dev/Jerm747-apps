"""Parallax-only momentum, sliding and held double-speed controls."""
from pathlib import Path
def patch(target):
 p=target/'runner.js';s=p.read_text();s=s.replace('let run,baseSheet', 'let momentum=GSRunnerMomentum.create();let run,baseSheet')
 s=s.replace('baseSheet=null;distance=0;', 'baseSheet=null;distance=0;momentum=GSRunnerMomentum.create();invulnerable=0;')
 # Held movement is released on pause, but physical momentum remains frozen until Resume.
 s=s.replace("const jump=p.jump||pressed(0),duck=", "const boost=pressed(7)||k('ShiftLeft')||k('ShiftRight')||values.includes('boost'),jump=p.jump||pressed(0),duck=")
 s=s.replace('return{left:', 'return{boost,left:')
 s=s.replace('if(p.attack&&!padLast.attack)edge.attack=p.attack;', "if(p.attack&&!padLast.attack&&!pressed(7))edge.attack=p.attack;")
 old="arcadeStep(run,i,dt);let delta=p.x-450;if(i.duck&&p.y>=-.5){const direction=(i.right?1:0)-(i.left?1:0);delta=direction*145*dt;if(direction)p.facing=direction;}distance=Math.max(0,distance+delta);p.x=450;"
 new="""const previousGait=p.gait,wasAir=p.y<0;arcadeStep(run,{...i,left:false,right:false,analogX:0,tapDirection:0},dt);let delta=GSRunnerMomentum.step(momentum,i,wasAir||p.y<0||p.launch>0,dt,p.hitAge>=0&&p.hitAge<.3);if(distance+delta<0){delta=-distance;momentum.vx=0;}distance=Math.max(0,distance+delta);p.x=450;const direction=Math.sign(momentum.vx);p.moveSpeed=Math.abs(momentum.vx);p.moveDir=direction;p.lastMovement=direction;p.facing=direction||p.facing;p.gait=(previousGait+Math.abs(delta)/96)%1;if(p.y>=0&&!p.attack&&p.launch<=0&&p.hitAge<0&&!i.duck){p.action=Math.abs(momentum.vx)>155?'run':Math.abs(momentum.vx)>1?'step':'idle';p.movePhase=Math.abs(momentum.vx)>1?'run':'idle';}"""
 assert old in s;s=s.replace(old,new)
 s=s.replace("['left','right','duck'].includes(a)", "['left','right','duck','boost'].includes(a)")
 s=s.replace("'KeyV','Space','KeyX'", "'KeyV','Space','KeyX','ShiftLeft','ShiftRight'")
 # Smooth scaling and a visible grounded skid during deceleration / duck slides.
 s=s.replace("ctx.clearRect(0,0,w,h);const viewW", "ctx.clearRect(0,0,w,h);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';const viewW")
 s=s.replace("if(baseSheet){const actor=", "if(baseSheet&&momentum.sliding&&run.battle.player.y>=0){ctx.save();ctx.strokeStyle='#d4e7dc88';ctx.lineWidth=2;for(let n=0;n<3;n++){const sign=Math.sign(momentum.vx)||1,x=playerX-sign*(20+n*12);ctx.beginPath();ctx.moveTo(x,ground-3-n*2);ctx.lineTo(x-sign*11,ground-3-n*2);ctx.stroke();}ctx.restore();}if(baseSheet){const actor=")
 # Draw travelling waves in the runner, which previously never painted its projectiles.
 s=s.replace("$('run-score').textContent=", "if(baseSheet&&window.GSVWave?.active(id))for(const wave of run.battle.projectiles){const local={...wave,x:playerX+(wave.x-450)};window.GSVWave?.flight(ctx,local,run.battle.t,matchMedia('(prefers-reduced-motion: reduce)').matches);} $('run-score').textContent=")
 # Renderer uses lifetime to animate transient runner copies; no per-frame birth reset.
 s=s.replace("const local={...wave,x:playerX+(wave.x-450)}", "const local={...wave,x:playerX+(wave.x-450),visualAge:2.7-wave.life}")
 s=s.replace("· best ${Math.floor(best/10)} m`", "· best ${Math.floor(best/10)} m · ${Math.round(Math.abs(momentum.vx))} speed${inputBoost?' · 2×':''}`") if False else s
 s=s.replace("duck:run?.battle.player.duckAmount", "duck:run?.battle.player.duckAmount,speed:momentum.vx,sliding:momentum.sliding,ready:!!baseSheet,boost:!!momentum.boost")
 s=s.replace('p.x=450;b.boss.x=10000;', 'p.x=450;b.boss.x=momentum.vx<0?-10000:10000;')
 # Keep projectile world coordinates separate from the fixed actor's engine coordinates.
 s=s.replace('let momentum=GSRunnerMomentum.create();', 'let runnerShots=[],runnerImpacts=[],destroyed=0;let momentum=GSRunnerMomentum.create();')
 s=s.replace('momentum=GSRunnerMomentum.create();invulnerable=0;', 'momentum=GSRunnerMomentum.create();runnerShots=[];runnerImpacts=[];destroyed=0;invulnerable=0;')
 s=s.replace('const previousGait=p.gait,wasAir=p.y<0;', 'const distanceBefore=distance,previousGait=p.gait,wasAir=p.y<0;b.projectiles=[];')
 s=s.replace('},dt);let delta=GSRunnerMomentum.step', '},dt);const emitted=b.projectiles;let delta=GSRunnerMomentum.step')
 needle='for(const o of obstacles){const dx=o.x-distance;'
 projectiles="""runnerImpacts=runnerImpacts.filter(e=>(e.life-=dt)>0);
for(const shot of runnerShots){shot.lastWorldX=shot.worldX;shot.worldX+=shot.worldVx*dt;shot.life-=dt;}
for(const wave of emitted){const worldVx=wave.vx+momentum.vx,worldX=distanceBefore+wave.x-450+momentum.vx*dt;runnerShots.push({...wave,worldX,lastWorldX:worldX-worldVx*dt,worldVx,height:wave.y-360+(id==='mama-love'?38:24),fighter:id});}
for(const shot of runnerShots){if(shot.life<=0)continue;for(const box of obstacles){if(box.type!=='block'||box.destroyed)continue;const radius=shot.fighter==='mama-love'?24:24,lo=Math.min(shot.lastWorldX,shot.worldX)-radius,hi=Math.max(shot.lastWorldX,shot.worldX)+radius;if(hi<box.x-27||lo>box.x+27||shot.height+radius<-58||shot.height-radius>0)continue;box.destroyed=true;if(!box.done)cleared++;box.done=true;destroyed++;shot.life=0;GSSound.play('ground',{impact:.65});runnerImpacts.push({fighter:shot.fighter,x:box.x,y:-36,life:.28});break;}}
runnerShots=runnerShots.filter(w=>w.life>0);b.projectiles=runnerShots;
"""
 assert needle in s;s=s.replace(needle,projectiles+needle)
 s=s.replace('for(const o of obstacles){const x=', 'for(const o of obstacles){if(o.destroyed)continue;const x=')
 # Both native effect and debris sit in world coordinates while the camera scrolls.
 s=s.replace("if(baseSheet&&window.GSVWave?.active(id))for(const wave of run.battle.projectiles){const local={...wave,x:playerX+(wave.x-450),visualAge:2.7-wave.life};window.GSVWave?.flight(ctx,local,run.battle.t,matchMedia('(prefers-reduced-motion: reduce)').matches);}", """const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
for(const wave of runnerShots){const local={...wave,x:playerX+wave.worldX-distance,y:ground+wave.height,visualAge:2.7-wave.life};if(window.GSVWave?.active(wave.fighter)&&window.GSVWave.flight(ctx,local,run.battle.t,reduced,{environment:'daylight',fighter:wave.fighter}))continue;ctx.save();ctx.strokeStyle=wave.color;ctx.lineWidth=5;ctx.beginPath();ctx.arc(local.x,local.y,20,-1.1,1.1);ctx.stroke();ctx.restore();}
for(const e of runnerImpacts){const x=playerX+e.x-distance;window.GSVWave?.impact(ctx,{...e,x,y:ground+e.y},reduced);if(!reduced){const t=.28-e.life;ctx.save();ctx.fillStyle='#e6ba78';ctx.globalAlpha=e.life/.28;for(let n=0;n<8;n++){const a=n*Math.PI/4,xx=x+Math.cos(a)*t*220,yy=ground-36+Math.sin(a)*t*180+340*t*t;ctx.save();ctx.translate(xx,yy);ctx.rotate(n+t*6);ctx.fillRect(-3,-3,6+n%2*3,6);ctx.restore();}ctx.restore();}}
""")
 s=s.replace('best ${Math.floor(best/10)} m`', 'best ${Math.floor(best/10)} m · ${Math.round(Math.abs(momentum.vx))} speed${momentum.boost?" · 2×":""}`')
 s=s.replace(' · ${hits} bumps', ' · ${destroyed} blasted · ${hits} bumps')
 s=s.replace('ready:!!baseSheet,boost:!!momentum.boost', 'ready:!!baseSheet,boost:!!momentum.boost,destroyed,shots:runnerShots.map(w=>({x:w.worldX,y:w.height,vx:w.worldVx,life:w.life})),obstacles:obstacles.map(o=>({...o}))')
 p.write_text(s)
 p=target/'runner.html' ;s=p.read_text().replace('<script src="/runner.js"></script>','<script src="/runner-momentum.js"></script><script src="/v-wave-frames.js"></script><script src="/v-wave.js"></script><script src="/runner.js"></script>')
 s=s.replace('<div class="run-actions">', '<div class="run-actions"><button data-action="boost" class="boost" aria-label="Hold for double speed running">2× SPEED <small>HOLD · Shift / R2</small></button>')
 s=s.replace('Hold → to build speed. Jump the low blocks.', 'Hold → to build speed. Hold 2× SPEED / Shift / R2 to run twice as fast. Carry speed through jumps; release to coast, or hold Duck to slide. Reverse direction to brake. Jump the low blocks.');p.write_text(s)

 # Compact held boost beside Jump, away from the arena center.
 p=target/'runner.html';h=p.read_text();a=h.index('<aside id="run-help">')+len('<aside id="run-help">');b=h.index('</aside>',a);h=h[:a]+'Hold 2× SPEED (Shift / R2) to sprint. Jump carries speed; Duck slides. V-wave blasts boxes. Reverse to brake.'+h[b:];p.write_text(h)
 p=target/'runner.css';p.write_text(p.read_text()+'\n.run-actions .boost{min-width:105px;height:38px;border-radius:12px;background:#185064d9;border-color:#8ff5ed}.run-actions .boost.pressed{background:#338e96}#run-help{top:110px;right:14px;bottom:auto;left:auto;max-width:290px;font-size:11px}\n')
