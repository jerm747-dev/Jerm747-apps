# Project naming

The brand and character name is **Jerm**, always with a J. Treat the dictation spelling “Germ” as “Jerm” when it refers to this brand or character. Use JERM 747 for uppercase branding and Jerm747 for the compact name.
