"""Install the verified build185 HD art without replacing combat artwork."""
from pathlib import Path
import shutil
def patch(target):
 root=Path(__file__).parent
 dest=target/'portraits-hd';dest.mkdir(exist_ok=True)
 for p in (root/'workshop-assets/portraits').glob('*.webp'):shutil.copyfile(p,dest/p.name)
 for n in ['intro-art.js','intro-art-frames.js']:shutil.copyfile(root/n,target/n)
 p=target/'assets/selection-looks.js';h=p.read_text();h=h.replace('imgs.forEach(img=>{img.onload=null;', 'imgs.forEach(img=>{window.GSIntroArt?.cancel(img);img.onload=null;')
 old="delete imgs[0].dataset.retried;imgs[0].src=identity?.portrait||src+'.webp?v='+v;"
 new="delete imgs[0].dataset.retried;const fallback=identity?.portrait||src+'.webp?v='+v;if(!window.GSIntroArt?.bind(imgs[0],id,fallback))imgs[0].src=fallback;"
 assert old in h,'Selection portrait binding changed';h=h.replace(old,new);p.write_text(h)
 p=target/'index.html';h=p.read_text()
 old="// These two use calibrated multi-sheet art: load it before the first attack, avoiding old-pose flashes."
 assert old in h;h=h.replace(old,"await window.GSIntroArt?.wait(snapshot);\n "+old,1)
 h=h.replace("function beginMatchIntro(full=true){resetInput();", "function beginMatchIntro(full=true){window.GSIntroArt?.wait([run.member,battle.opponent]);resetInput();")
 h=h.replace("reloadAssets:()=>{window.GSVWave?.load(true);", "reloadAssets:()=>{window.GSVWave?.load(true);window.GSIntroArt?.retry([chosen,opponentChoice]);")
 p.write_text(h)
