"""Copy the existing browser app and apply Android-only integration patches."""
import pathlib,shutil,sys
root=pathlib.Path(__file__).resolve().parent
source=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'gs-fighter'/'public'
target=root/'app/src/main/assets'
if not (source/'index.html').exists():raise SystemExit('Pass the public/ folder from GS-Fighter-1.0.')
for entry in source.iterdir():
 dest=target/entry.name
 if entry.is_dir():shutil.copytree(entry,dest,dirs_exist_ok=True)
 else:shutil.copy2(entry,dest)
for name in ['index.html','runner.html','workshop.html','sound-workshop.html']:
 p=target/name;h=p.read_text();h=h.replace('</head>','<link rel="stylesheet" href="/android.css"><script src="/android.js"></script></head>') if '</head>' in h else h.replace('<body>','<link rel="stylesheet" href="/android.css"><script src="/android.js"></script><body>');p.write_text(h)
p=target/'gs-sound.js';h=p.read_text().replace('window.GSSound={play,','window.GSSound={suspend:()=>{audio.pause();ctx?.suspend();},play,');p.write_text(h)
import runpy
runpy.run_path(str(root/'patch-game.py'))['patch'](target)
runpy.run_path(str(root/'patch-music.py'))['patch'](target)
runpy.run_path(str(root/'patch-portraits.py'))['patch'](target)
runpy.run_path(str(root/'patch-development.py'))['patch'](target)
# Expose a stable app-private origin; local file permissions are not needed.
import hashlib,json
assets=[]
for p in sorted(target.rglob('*')):
 if p.is_file() and p.name!='asset-manifest.json' and not any(part.startswith('.') for part in p.relative_to(target).parts):assets.append({'url':'/'+str(p.relative_to(target)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(target/'asset-manifest.json').write_text(json.dumps(assets,indent=2))
print('Android bundle:',len(assets),'files; source unchanged')
