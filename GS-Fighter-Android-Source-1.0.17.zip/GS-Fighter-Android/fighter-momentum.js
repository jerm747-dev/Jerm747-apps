/* Shared deterministic player movement for fighter mode. CPU decisions remain independent. */
function arcadeFighterMomentum(p,a,input,dt,movement,guardRetreat){
 const approach=(v,t,n)=>v<t?Math.min(t,v+n):Math.max(t,v-n),air=p.y<0||p.launch>0,stunned=p.hitAge>=0&&p.hitAge<.3;
 let vx=p.momentumVx||0;const axis=Number.isFinite(input.moveAxis)?Math.abs(input.moveAxis):1,cap=ARCADE_MOVEMENT.run*(axis>.08?Math.max(.35,axis):1),wave=p.attack?.move==='wave';
 if(stunned)vx=0;
 else if(air){if(movement)vx=approach(vx,movement*cap,(vx*movement<0?300:190)*dt);}
 else if(p.guard&&input.block&&!input.duck){vx=approach(vx,guardRetreat?movement*107.25:0,1050*dt);}
 else if(p.attack&&!wave){vx=approach(vx,0,1050*dt);}
 else if(movement&&vx*movement<0)vx=approach(vx,0,1050*dt);
 else if(input.duck&&p.guard){vx=Math.abs(vx)>105||!movement?approach(vx,0,1600*dt):approach(vx,movement*105,620*dt);}
 else if(movement)vx=approach(vx,movement*cap,620*dt);
 else vx=approach(vx,0,1800*dt);
 const oldX=p.x;p.x=Math.max(60,Math.min(840,p.x+vx*dt));if(p.x===oldX&&Math.abs(vx)>0&&(p.x===60||p.x===840))vx=0;
 p.momentumVx=vx;p.sliding=!air&&Math.abs(vx)>35&&(!!input.duck||!movement||movement*vx<0);p.moveSpeed=Math.abs(vx);p.moveDir=Math.sign(vx);p.lastMovement=Math.sign(vx);p.gait=((p.gait||0)+Math.abs(p.x-oldX)/96)%1;p.moveAge=(p.moveAge||0)+dt;
 if(stunned||p.attack||air)return;
 if(p.guard){p.action=guardRetreat?'back-block':'block';p.anim=p.duckAmount>0?0:.08;return;}
 if(Math.abs(vx)>1){p.action=vx*p.facing<0?'backstep':Math.abs(vx)>150?'run':'step';p.movePhase=p.sliding?'stop':'run';}else{p.action='idle';p.movePhase='idle';}
}
