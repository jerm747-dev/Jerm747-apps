package com.jerm747.gsfighter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://" + HOST;
    private static final int IMPORT = 741, EXPORT = 742;
    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> fileCallback;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private InputManager inputs;
    private final Map<Integer, Pad> pads = new HashMap<>();
    private volatile boolean trusted = false;
    private boolean loaded = false;
    private ExportSession export;
    private static final class ExportSession {
        final String id, name, mime; final File file; OutputStream stream; long size;
        ExportSession(String id, String name, String mime, File file, OutputStream stream) {
            this.id=id; this.name=name; this.mime=mime; this.file=file; this.stream=stream;
        }
    }
    private static final class Pad {
        final int device, index; final String name; final float[] axes = new float[4];
        final float[] buttons = new float[17]; final boolean[] keys = new boolean[17];
        float hatX, hatY, lt, rt;
        Pad(int device, int index, String name){this.device=device;this.index=index;this.name=name;}
        JSONObject json() throws Exception {
            JSONObject p=new JSONObject();p.put("index",index);p.put("id","GS Android · "+name);
            p.put("mapping","standard");p.put("connected",true);p.put("timestamp",android.os.SystemClock.uptimeMillis());
            JSONArray a=new JSONArray();for(float v:axes)a.put(v);p.put("axes",a);
            JSONArray b=new JSONArray();for(int i=0;i<buttons.length;i++){
                float v=Math.max(buttons[i],keys[i]?1:0);
                if(i==6)v=Math.max(v,lt);if(i==7)v=Math.max(v,rt);
                if(i==12&&hatY<-.5f||i==13&&hatY>.5f||i==14&&hatX<-.5f||i==15&&hatX>.5f)v=1;
                JSONObject value=new JSONObject();value.put("pressed",v>.5);value.put("touched",v>0);value.put("value",v);b.put(value);
            }p.put("buttons",b);return p;
        }
        void clear(){java.util.Arrays.fill(axes,0);java.util.Arrays.fill(buttons,0);java.util.Arrays.fill(keys,false);hatX=hatY=lt=rt=0;}
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root=new FrameLayout(this);root.setBackgroundColor(0xff000000);setContentView(root);
        web=new WebView(this);web.setOnLongClickListener(v->true);web.setBackgroundColor(0xff000000);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);s.setTextZoom(100);
        s.setUserAgentString(s.getUserAgentString()+" GSFighterAndroid/1.0");
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.addJavascriptInterface(new AndroidBridge(),"GSAndroid");
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                Uri u=request.getUrl();
                if("https".equals(u.getScheme())&&HOST.equals(u.getHost())){
                    if(!"GET".equals(request.getMethod())&&!"HEAD".equals(request.getMethod()))return response(405,"Method Not Allowed");
                    WebResourceResponse r=loader.shouldInterceptRequest(u);
                    if(r==null||r.getData()==null)return response(404,"File not found");
                    String path=u.getPath()==null?"":u.getPath();
                    if(path.endsWith(".js")||path.endsWith(".mjs"))r.setMimeType("text/javascript");
                    if(path.endsWith(".json"))r.setMimeType("application/json");
                    if(path.endsWith(".html"))r.setMimeType("text/html");
                    if(path.endsWith(".css"))r.setMimeType("text/css");
                    Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-cache");
                    headers.put("X-Content-Type-Options","nosniff");headers.put("Content-Security-Policy","default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; frame-src 'self'");
                    r.setResponseHeaders(headers);return r;
                }
                if("data".equals(u.getScheme())||"blob".equals(u.getScheme()))return null;
                return response(403,"Offline content only");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !isLocal(request.getUrl());}
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){trusted=isLocal(Uri.parse(url));loaded=false;}
            @Override public void onPageFinished(WebView view,String url){loaded=true;publishPads();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
                Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);
                java.util.ArrayList<String> types=new java.util.ArrayList<>();
                for(String accept:params.getAcceptTypes())if(accept!=null)for(String part:accept.split(",")){
                    String type=part.trim();if(type.startsWith(".")){if(type.equals(".json"))type="application/json";else continue;}
                    if(type.contains("/"))types.add(type);
                }
                pick.setType(types.size()==1?types.get(0):"*/*");if(types.size()>1)pick.putExtra(Intent.EXTRA_MIME_TYPES,types.toArray(new String[0]));
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                try{startActivityForResult(pick,IMPORT);}catch(ActivityNotFoundException e){fileCallback.onReceiveValue(null);fileCallback=null;toast("No file picker is available.");}
                return true;
            }
            @Override public void onShowCustomView(View view,CustomViewCallback callback){
                if(customView!=null){callback.onCustomViewHidden();return;}customView=view;customCallback=callback;
                root.addView(view,new FrameLayout.LayoutParams(-1,-1));web.setVisibility(View.GONE);immersive();
            }
            @Override public void onHideCustomView(){hideCustom();}
        });
        inputs=(InputManager)getSystemService(INPUT_SERVICE);inputs.registerInputDeviceListener(this,ui);
        for(int device:InputDevice.getDeviceIds())ensurePad(device);
        web.loadUrl(ORIGIN+"/index.html");immersive();
    }
    private static boolean isLocal(Uri uri){return "https".equals(uri.getScheme())&&HOST.equals(uri.getHost());}
    private static WebResourceResponse response(int status,String text){return new WebResourceResponse("text/plain","UTF-8",status,text,new HashMap<>(),new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));}
    private void js(String code){if(web!=null&&!isFinishing()&&loaded)web.evaluateJavascript(code,null);}
    private void toast(String message){ui.post(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
    private void hideCustom(){if(customView==null)return;root.removeView(customView);customView=null;web.setVisibility(View.VISIBLE);if(customCallback!=null)customCallback.onCustomViewHidden();customCallback=null;immersive();}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)immersive();else{js("window.GSAndroidLifecycle?.pause();");clearPads();}}
    @Override protected void onPause(){js("window.GSAndroidLifecycle?.pause();");clearPads();if(web!=null){web.onPause();web.pauseTimers();}super.onPause();}
    @Override protected void onResume(){super.onResume();if(web!=null){web.resumeTimers();web.onResume();}immersive();}
    @Override protected void onDestroy(){if(inputs!=null)inputs.unregisterInputDeviceListener(this);if(fileCallback!=null)fileCallback.onReceiveValue(null);io.shutdown();if(web!=null){web.removeJavascriptInterface("GSAndroid");root.removeView(web);web.destroy();web=null;}super.onDestroy();}
    @Override public void onBackPressed(){if(customView!=null){hideCustom();return;}js("window.GSAndroidLifecycle?.pause();");new AlertDialog.Builder(this).setTitle("GS Fighter").setItems(new String[]{"Resume","Fighter select","Parallax Run","Sprite Workshop","Sound Workshop","Controller setup","Exit"},(d,which)->{
        if(which==0){js("window.GSAndroidLifecycle?.resume();");return;}
        if(which==6){finish();return;}
        if(which==5){js("window.Jerm747Controls?.openHelp('pad');");return;}
        String[] routes={"","/index.html","/runner.html","/workshop.html","/sound-workshop.html"};
        web.loadUrl(ORIGIN+routes[which]);
    }).setNegativeButton("Close",(d,w)->{}).setOnDismissListener(d->{immersive();web.requestFocus();}).show();}

    private boolean isGameDevice(InputDevice device){return device!=null&&((device.getSources()&InputDevice.SOURCE_GAMEPAD)==InputDevice.SOURCE_GAMEPAD||(device.getSources()&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK);}
    private Pad ensurePad(int device){if(pads.containsKey(device))return pads.get(device);InputDevice d=InputDevice.getDevice(device);if(!isGameDevice(d))return null;int slot=0;while(slot<4){final int index=slot;if(pads.values().stream().noneMatch(p->p.index==index))break;slot++;}if(slot==4)return null;Pad p=new Pad(device,slot,d.getName());pads.put(device,p);return p;}
    private void publishPads(){try{JSONArray all=new JSONArray();for(Pad p:pads.values())all.put(p.json());js("window.GSAndroidPads?.update("+all+");");}catch(Exception ignored){}}
    private void clearPads(){for(Pad p:pads.values())p.clear();publishPads();}
    @Override public void onInputDeviceAdded(int id){ensurePad(id);publishPads();}
    @Override public void onInputDeviceRemoved(int id){pads.remove(id);publishPads();}
    @Override public void onInputDeviceChanged(int id){pads.remove(id);ensurePad(id);publishPads();}
    static int standardButton(int code){return switch(code){
        case KeyEvent.KEYCODE_BUTTON_A->0;case KeyEvent.KEYCODE_BUTTON_B->1;case KeyEvent.KEYCODE_BUTTON_X->2;case KeyEvent.KEYCODE_BUTTON_Y->3;
        case KeyEvent.KEYCODE_BUTTON_L1->4;case KeyEvent.KEYCODE_BUTTON_R1->5;case KeyEvent.KEYCODE_BUTTON_L2->6;case KeyEvent.KEYCODE_BUTTON_R2->7;
        case KeyEvent.KEYCODE_BUTTON_SELECT->8;case KeyEvent.KEYCODE_BUTTON_START->9;case KeyEvent.KEYCODE_BUTTON_THUMBL->10;case KeyEvent.KEYCODE_BUTTON_THUMBR->11;
        case KeyEvent.KEYCODE_DPAD_UP->12;case KeyEvent.KEYCODE_DPAD_DOWN->13;case KeyEvent.KEYCODE_DPAD_LEFT->14;case KeyEvent.KEYCODE_DPAD_RIGHT->15;case KeyEvent.KEYCODE_BUTTON_MODE->16;default->-1;};}
    @Override public boolean dispatchKeyEvent(KeyEvent event){Pad p=ensurePad(event.getDeviceId());int button=standardButton(event.getKeyCode());if(p!=null&&button>=0){if(event.getAction()==KeyEvent.ACTION_DOWN)p.keys[button]=true;else if(event.getAction()==KeyEvent.ACTION_UP)p.keys[button]=false;publishPads();return true;}return super.dispatchKeyEvent(event);}
    private static float axis(MotionEvent event,int axis){float value=event.getAxisValue(axis);InputDevice.MotionRange range=event.getDevice()==null?null:event.getDevice().getMotionRange(axis,event.getSource());return Math.abs(value)<Math.max(.08f,range==null?0:range.getFlat())?0:value;}
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event){Pad p=ensurePad(event.getDeviceId());if(p!=null&&event.getAction()==MotionEvent.ACTION_MOVE){
        p.axes[0]=axis(event,MotionEvent.AXIS_X);p.axes[1]=axis(event,MotionEvent.AXIS_Y);
        boolean zr=event.getDevice()!=null&&event.getDevice().getMotionRange(MotionEvent.AXIS_Z,event.getSource())!=null&&event.getDevice().getMotionRange(MotionEvent.AXIS_RZ,event.getSource())!=null;
        p.axes[2]=axis(event,zr?MotionEvent.AXIS_Z:MotionEvent.AXIS_RX);p.axes[3]=axis(event,zr?MotionEvent.AXIS_RZ:MotionEvent.AXIS_RY);
        p.hatX=event.getAxisValue(MotionEvent.AXIS_HAT_X);p.hatY=event.getAxisValue(MotionEvent.AXIS_HAT_Y);
        p.lt=Math.max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER),event.getAxisValue(MotionEvent.AXIS_BRAKE));
        p.rt=Math.max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER),event.getAxisValue(MotionEvent.AXIS_GAS));publishPads();return true;
    }return super.dispatchGenericMotionEvent(event);}

    private final class AndroidBridge {
        @JavascriptInterface public void menu(){ui.post(()->onBackPressed());}
        @JavascriptInterface public void requestPads(){ui.post(()->publishPads());}
        @JavascriptInterface public void vibrate(int duration){if(!trusted)return;int ms=Math.min(150,Math.max(0,duration));Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null){if(ms==0)v.cancel();else if(v.hasVibrator())v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE));}}
        @JavascriptInterface public synchronized String beginExport(String name,String mime){if(!trusted)return "";synchronized(MainActivity.this){if(export!=null)return "";try{String safe=name.replaceAll("[^a-zA-Z0-9_.-]","_");if(safe.length()>100)safe=safe.substring(0,100);if(safe.trim().isEmpty()||safe.equals(".")||safe.equals(".."))safe="gs-export.bin";String id=UUID.randomUUID().toString();File file=new File(getCacheDir(),"export-"+id);export=new ExportSession(id,safe,mime,file,new FileOutputStream(file));return id;}catch(Exception e){toast("Export could not start.");return "";}}}
        @JavascriptInterface public boolean appendExport(String id,String base64){synchronized(MainActivity.this){if(export==null||!export.id.equals(id)||export.stream==null||base64.length()>400000)return false;try{byte[] bytes=android.util.Base64.decode(base64,android.util.Base64.DEFAULT);export.size+=bytes.length;if(export.size>120L*1024*1024)throw new Exception("File too large");export.stream.write(bytes);return true;}catch(Exception e){cancelExport(id);return false;}}}
        @JavascriptInterface public void finishExport(String id){synchronized(MainActivity.this){if(export==null||!export.id.equals(id)||export.stream==null)return;try{export.stream.close();export.stream=null;}catch(Exception e){cancelExport(id);return;}ExportSession pending=export;ui.post(()->{try{Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType(pending.mime);save.putExtra(Intent.EXTRA_TITLE,pending.name);startActivityForResult(save,EXPORT);}catch(Exception e){cancelExport(id);toast("No export destination picker is available.");}});}}
        @JavascriptInterface public void cancelExport(String id){synchronized(MainActivity.this){if(export!=null&&export.id.equals(id)){try{if(export.stream!=null)export.stream.close();}catch(Exception ignored){}export.file.delete();export=null;}}}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==IMPORT){if(fileCallback!=null){Uri[] chosen=null;if(result==RESULT_OK&&data!=null){if(data.getClipData()!=null){chosen=new Uri[data.getClipData().getItemCount()];for(int i=0;i<chosen.length;i++)chosen[i]=data.getClipData().getItemAt(i).getUri();}else if(data.getData()!=null)chosen=new Uri[]{data.getData()};}fileCallback.onReceiveValue(chosen);fileCallback=null;}}
        if(request==EXPORT){ExportSession pending;synchronized(this){pending=export;export=null;}if(pending==null)return;
            if(result!=RESULT_OK||data==null||data.getData()==null){pending.file.delete();toast("Export cancelled.");return;}Uri destination=data.getData();
            io.execute(()->{try(FileInputStream in=new FileInputStream(pending.file);OutputStream out=getContentResolver().openOutputStream(destination,"w")){if(out==null)throw new Exception("No destination");byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);toast("Saved "+pending.name);}catch(Exception e){toast("Could not save file. Try another destination.");}finally{pending.file.delete();}});
        }
    }
}
