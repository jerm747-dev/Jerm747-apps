'use strict';
// Job paths in the UI are POSIX-style "virtual" paths like
// /Products/Middleware/WebSphere/.../WAS Upgrade 9.0.5.29_r02
// Every adapter runs them through cleanVirtual() first, which rejects anything
// that could escape the configured root.
const path = require('path');

function cleanVirtual(p) {
  if (typeof p !== 'string' || !p.trim()) throw badRequest('A path is required.');
  if (p.includes('\0')) throw badRequest('Invalid path.');
  const parts = p.replace(/\\/g, '/').split('/').filter(Boolean);
  if (parts.some(s => s === '..')) throw badRequest('Paths may not contain "..".');
  return '/' + parts.filter(s => s !== '.').join('/');
}

function cleanFileName(name, { ext } = {}) {
  if (typeof name !== 'string' || !name.trim()) throw badRequest('A file name is required.');
  if (/[\/\\\0]/.test(name) || name === '.' || name === '..') throw badRequest('Invalid file name.');
  if (ext && !name.toLowerCase().endsWith(ext)) throw badRequest(`File name must end in ${ext}.`);
  return name;
}

// Map a virtual path under a real directory, refusing anything outside it.
function underRoot(root, virtual) {
  const full = path.resolve(root, '.' + cleanVirtual(virtual));
  const rel = path.relative(root, full);
  if (rel.startsWith('..') || path.isAbsolute(rel)) throw badRequest('Path is outside the configured root.');
  return full;
}

function badRequest(message, status = 400) {
  const e = new Error(message);
  e.status = status;
  return e;
}

module.exports = { cleanVirtual, cleanFileName, underRoot, badRequest };
