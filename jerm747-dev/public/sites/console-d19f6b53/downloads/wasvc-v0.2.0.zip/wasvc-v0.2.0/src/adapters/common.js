'use strict';

const MAX_FILES = 5000;

// [{ rel: 'AppA/DEV/mapping.xml', content }]  ->  [{ folder: '<source>/AppA/DEV', files: [{ path, content }] }]
// Each folder that holds a mapping.xml is one job folder. File paths stay relative to the source.
function groupByFolder(source, found) {
  const byFolder = new Map();
  for (const f of found) {
    const relDir = f.rel.includes('/') ? f.rel.slice(0, f.rel.lastIndexOf('/')) : '';
    const folder = relDir ? `${source}/${relDir}` : source;
    if (!byFolder.has(folder)) byFolder.set(folder, []);
    byFolder.get(folder).push({ path: f.rel, content: f.content });
  }
  return [...byFolder.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([folder, files]) => ({ folder, files }));
}

module.exports = { groupByFolder, MAX_FILES };
