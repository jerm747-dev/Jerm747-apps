'use strict';
// Loads wasvc.config.json (or the file named by WASVC_CONFIG) on top of safe defaults.
const fs = require('fs');
const path = require('path');
const os = require('os');

const ROOT = path.resolve(__dirname, '..');

const DEFAULTS = {
  host: '127.0.0.1',            // localhost only; change deliberately if others must reach it
  port: 7474,
  jobsBase: '/Products/Middleware/WebSphere/Teams/CDTS/Build/DAIT/WAS Fixpack Upgrade',
  maxUploadMB: 50,
  source: { type: 'local', root: './sample-jobs' },
};

function expandHome(p) {
  return typeof p === 'string' && p.startsWith('~') ? path.join(os.homedir(), p.slice(1)) : p;
}

function load() {
  const file = process.env.WASVC_CONFIG
    ? path.resolve(process.env.WASVC_CONFIG)
    : path.join(ROOT, 'wasvc.config.json');
  let user = {};
  if (fs.existsSync(file)) {
    try { user = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { throw new Error(`Could not parse ${file}: ${e.message}`); }
  }
  const cfg = { ...DEFAULTS, ...user, source: { ...DEFAULTS.source, ...(user.source || {}) } };
  if (process.env.PORT) cfg.port = Number(process.env.PORT);

  const s = cfg.source;
  if (s.type === 'local') s.root = path.resolve(ROOT, expandHome(s.root));
  if (s.identityFile) s.identityFile = expandHome(s.identityFile);
  cfg.configFile = fs.existsSync(file) ? file : null;
  return cfg;
}

module.exports = { load, ROOT };
