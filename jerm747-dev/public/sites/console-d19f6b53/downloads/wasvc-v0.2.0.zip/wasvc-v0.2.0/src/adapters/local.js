'use strict';
// Local folder adapter: job folders live on this machine under `root`.
// The virtual path /Products/... maps to <root>/Products/...
const fs = require('fs/promises');
const path = require('path');
const { cleanVirtual, underRoot, badRequest } = require('../paths');
const { groupByFolder, MAX_FILES } = require('./common');

function createLocalAdapter({ root }) {
  return {
    type: 'local',
    label: `Local folder (${path.basename(root)})`,
    describe: () => ({ type: 'local', label: `Local folder (${path.basename(root)})`, root }),

    async listFolders(virtual) {
      const dir = underRoot(root, virtual);
      const entries = await fs.readdir(dir, { withFileTypes: true }).catch(err => {
        throw err.code === 'ENOENT' ? badRequest(`Folder not found: ${cleanVirtual(virtual)}`, 404) : err;
      });
      return entries.filter(e => e.isDirectory()).map(e => e.name).sort((a, b) => a.localeCompare(b));
    },

    async readMappingTree(sourceVirtual) {
      const source = cleanVirtual(sourceVirtual);
      const base = underRoot(root, source);
      const found = [];
      async function walk(dir) {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        for (const e of entries) {
          const full = path.join(dir, e.name);
          if (e.isDirectory()) await walk(full);
          else if (e.isFile() && e.name === 'mapping.xml') {
            if (found.length >= MAX_FILES) throw badRequest(`More than ${MAX_FILES} mapping.xml files; pick a narrower source folder.`, 413);
            found.push({ rel: path.relative(base, full).split(path.sep).join('/'), content: await fs.readFile(full, 'utf8') });
          }
        }
      }
      await walk(base).catch(err => {
        throw err.code === 'ENOENT' ? badRequest(`Source folder not found: ${source}`, 404) : err;
      });
      return groupByFolder(source, found);
    },

    async writeFile(dirVirtual, name, buffer, { overwrite = false } = {}) {
      const dir = underRoot(root, dirVirtual);
      await fs.mkdir(dir, { recursive: true });
      const target = path.join(dir, name);
      const tmp = `${target}.wasvc-${process.pid}-${Date.now()}.tmp`;
      await fs.writeFile(tmp, buffer);
      try {
        if (!overwrite) {
          // link() fails if the target exists, so this is an atomic "create only"
          await fs.link(tmp, target).catch(err => {
            throw err.code === 'EEXIST' ? badRequest(`${name} already exists.`, 409) : err;
          });
        } else {
          await fs.rename(tmp, target);
        }
      } finally {
        await fs.rm(tmp, { force: true });
      }
      return `${cleanVirtual(dirVirtual)}/${name}`.replace(/\/{2,}/g, '/');
    },
  };
}

module.exports = { createLocalAdapter };
