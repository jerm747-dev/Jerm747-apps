'use strict';
// WASVC backend: serves the console UI and a small JSON API.
// Built on Node's own http module, so it runs with plain `node` and no npm install.
//
//   GET  /api/health                      -> which source is active
//   GET  /api/folders?path=/Products/...   -> child folder names
//   POST /api/read    { source }           -> every mapping.xml under source, grouped by job folder
//   POST /api/upload?dir=..&name=..&overwrite=0|1   (body: the ZIP bytes)
const http = require('http');
const fs = require('fs');
const path = require('path');
const { load, ROOT } = require('./config');
const { cleanVirtual, cleanFileName, badRequest } = require('./paths');
const { createLocalAdapter } = require('./adapters/local');
const { createSftpAdapter } = require('./adapters/sftp');
const { createBlcliAdapter } = require('./adapters/blcli');
const { version: VERSION } = require('../package.json');

function createAdapter(source) {
  switch (source.type) {
    case 'local': return createLocalAdapter(source);
    case 'sftp':  return createSftpAdapter(source);
    case 'blcli': return createBlcliAdapter(source);
    default: throw new Error(`Unknown source.type "${source.type}" (use local, sftp or blcli).`);
  }
}

function createServer(cfg) {
  const adapter = createAdapter(cfg.source);
  const publicDir = path.join(ROOT, 'public');
  const maxUpload = cfg.maxUploadMB * 1024 * 1024;
  const allowedHosts = new Set([`localhost:${cfg.port}`, `127.0.0.1:${cfg.port}`, `[::1]:${cfg.port}`, `${cfg.host}:${cfg.port}`]);

  const send = (res, status, body, type = 'application/json; charset=utf-8') => {
    const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
    res.writeHead(status, {
      'Content-Type': type,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
    });
    res.end(data);
  };

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', c => {
        size += c.length;
        if (size > limit) { reject(badRequest(`Upload is larger than ${cfg.maxUploadMB} MB.`, 413)); req.destroy(); return; }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }

  async function readJson(req) {
    const buf = await readBody(req, 1024 * 1024);
    try { return JSON.parse(buf.toString('utf8') || '{}'); }
    catch { throw badRequest('Request body must be JSON.'); }
  }

  async function handleApi(req, res, url) {
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return send(res, 200, { ok: true, version: VERSION, source: adapter.describe(), jobsBase: cfg.jobsBase });
    }
    if (req.method === 'GET' && url.pathname === '/api/folders') {
      const p = cleanVirtual(url.searchParams.get('path') || cfg.jobsBase);
      return send(res, 200, { path: p, folders: await adapter.listFolders(p) });
    }
    if (req.method === 'POST' && url.pathname === '/api/read') {
      const { source } = await readJson(req);
      const jobs = await adapter.readMappingTree(cleanVirtual(source));
      return send(res, 200, { source: cleanVirtual(source), jobs });
    }
    if (req.method === 'POST' && url.pathname === '/api/upload') {
      const dir = cleanVirtual(url.searchParams.get('dir') || '');
      const name = cleanFileName(url.searchParams.get('name') || '', { ext: '.zip' });
      const body = await readBody(req, maxUpload);
      const isZip = body.length >= 4 && body[0] === 0x50 && body[1] === 0x4b && (body[2] === 3 || body[2] === 5);
      if (!isZip) throw badRequest('Body is not a ZIP file.');
      const written = await adapter.writeFile(dir, name, body, { overwrite: url.searchParams.get('overwrite') === '1' });
      return send(res, 201, { ok: true, path: written, bytes: body.length });
    }
    throw badRequest('Not found.', 404);
  }

  function serveStatic(req, res, url) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Method not allowed.' });
    const rel = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
    const file = path.resolve(publicDir, rel);
    if (!file.startsWith(publicDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
    }
    const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };
    send(res, 200, fs.readFileSync(file), types[path.extname(file)] || 'application/octet-stream');
  }

  return http.createServer(async (req, res) => {
    const started = Date.now();
    res.on('finish', () => console.log(`${req.method} ${req.url.split('?')[0]} ${res.statusCode} ${Date.now() - started}ms`));
    try {
      // Reject requests not addressed to this server (DNS rebinding) or posted from another site (CSRF).
      if (!allowedHosts.has(req.headers.host)) throw badRequest('Unexpected Host header.', 403);
      const origin = req.headers.origin;
      if (req.method !== 'GET' && origin && !allowedHosts.has(origin.replace(/^https?:\/\//, ''))) {
        throw badRequest('Cross-origin request refused.', 403);
      }
      const url = new URL(req.url, `http://${req.headers.host}`);
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else serveStatic(req, res, url);
    } catch (err) {
      const status = err.status || 500;
      if (status >= 500) console.error(err);
      if (!res.headersSent) send(res, status, { error: status >= 500 && !err.status ? 'Internal error. See the server log.' : err.message });
    }
  });
}

if (require.main === module) {
  const cfg = load();
  const server = createServer(cfg);
  server.listen(cfg.port, cfg.host, () => {
    console.log(`WASVC v${VERSION} running at http://${cfg.host === '0.0.0.0' ? 'localhost' : cfg.host}:${cfg.port}`);
    console.log(`Source: ${JSON.stringify(createAdapter(cfg.source).describe())}`);
    console.log(`Config: ${cfg.configFile || '(defaults)'}`);
  });
}

module.exports = { createServer, createAdapter };
