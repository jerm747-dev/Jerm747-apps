'use strict';
// BladeLogic / BSA adapter: placeholder until blcli access is available.
//
// Planned flow (same four actions as the other adapters):
//   listFolders     -> list job groups under a BSA job path
//   readMappingTree -> export the job folder with blcli; the export writes mapping.xml files
//   writeFile       -> keep the normalized package on the WASVC host
//   (new) import    -> blcli ImportExport importObject into a new version job group,
//                      using the normalized mapping.xml
//
// Needs, on the machine running WASVC:
//   - the BSA console (RCP client), which installs NSH, blcli and blcred
//     (typically <BladeLogic home>/<version>/NSH/bin; confirm with `where blcli` / `which blcli`)
//   - an authentication profile matching the console's, with a session credential
//     from `blcred cred -acquire`, so WASVC never handles the password itself
//   - the role from the Connect step (e.g. DEPLOYERADV_MW_CSW_NP_BL)
// For speed, prefer one NSH session (blcli_setoption serviceProfileName/roleName,
// blcli_connect, blcli_execute) over one standalone blcli process per call.
// Confirm exact command signatures against the installed BSA version's BLCLI reference.
//
// Known for the team's version (Server Automation Console 25.4.00.52):
//   blcli ImportExport exportObject <objectType:int> <objectDBKey> <outputPath>
//     - one object per call; NSH Script Job = 111; overwrites files already in outputPath
//     - DBKey comes from a getDBKeyByGroupAndName-style lookup on the object's namespace
//   Patching, Provision and Virtual Guest jobs cannot be exported.
//   The WAS fixpack jobs are NSH Script Jobs (111), so they can be.
//   Job listAllByGroup <group>                          -> jobs in a group
//   NSHScriptJob getDBKeyByGroupAndName <group> <job>   -> DBKey for exportObject
//   tools/probe/try-export.nsh runs this sequence by hand for one job.
const { badRequest } = require('../paths');

function createBlcliAdapter(cfg = {}) {
  const notYet = () => { throw badRequest('The BladeLogic (blcli) adapter is not wired up yet. Use the local or sftp source for now.', 501); };
  return {
    type: 'blcli',
    label: 'BladeLogic (blcli, not wired)',
    describe: () => ({ type: 'blcli', label: 'BladeLogic (blcli, not wired)', profile: cfg.profile || null }),
    listFolders: notYet,
    readMappingTree: notYet,
    writeFile: notYet,
  };
}

module.exports = { createBlcliAdapter };
