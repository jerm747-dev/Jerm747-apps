'use strict';
// Minimal reader for uncompressed tar streams (ustar, GNU long names, pax paths).
// Used by the SFTP adapter to pull every mapping.xml in one SSH round trip.

function readString(buf, start, len) {
  const slice = buf.subarray(start, start + len);
  const nul = slice.indexOf(0);
  return slice.subarray(0, nul === -1 ? len : nul).toString('utf8');
}

function readOctal(buf, start, len) {
  const s = readString(buf, start, len).trim();
  return s ? parseInt(s, 8) : 0;
}

function parseTar(buf) {
  const files = [];
  let offset = 0;
  let longName = null;
  while (offset + 512 <= buf.length) {
    const header = buf.subarray(offset, offset + 512);
    if (header.every(b => b === 0)) break;                     // end-of-archive block
    const size = readOctal(header, 124, 12);
    const type = String.fromCharCode(header[156] || 48);      // '0' when unset
    const magic = readString(header, 257, 6);
    let name = readString(header, 0, 100);
    if (magic.startsWith('ustar')) {
      const prefix = readString(header, 345, 155);
      if (prefix) name = `${prefix}/${name}`;
    }
    const dataStart = offset + 512;
    const data = buf.subarray(dataStart, dataStart + size);
    offset = dataStart + Math.ceil(size / 512) * 512;

    if (type === 'L') { longName = readString(data, 0, data.length); continue; }   // GNU long name
    if (type === 'x') {                                                              // pax header
      const m = data.toString('utf8').match(/\d+ path=([^\n]*)\n/);
      if (m) longName = m[1];
      continue;
    }
    if (type === 'g') continue;
    if (longName) { name = longName; longName = null; }
    if (type === '0' || type === '\0') files.push({ name: name.replace(/^\.\//, ''), data: Buffer.from(data) });
  }
  return files;
}

module.exports = { parseTar };
