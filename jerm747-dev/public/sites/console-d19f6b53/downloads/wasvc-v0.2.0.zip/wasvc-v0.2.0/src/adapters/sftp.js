'use strict';
// SSH adapter: job folders live on a remote server you can SSH into.
// Uses the system `ssh` command (OpenSSH), so there is nothing to npm install.
// Auth is key-based only (BatchMode=yes): no passwords are typed, stored or passed around.
// Host keys are checked normally; connect once by hand with `ssh user@host` to trust a new server.
const { spawn } = require('child_process');
const path = require('path');
const { cleanVirtual, badRequest } = require('../paths');
const { groupByFolder, MAX_FILES } = require('./common');
const { parseTar } = require('../tar');

// Single-quote for POSIX sh: abc'd -> 'abc'\''d'
const sq = s => `'${String(s).replace(/'/g, `'\\''`)}'`;

function createSftpAdapter(cfg) {
  const { host, user, port = 22, identityFile, root = '', sshBin = 'ssh', sshOptions = [], timeoutSec = 60 } = cfg;
  if (!host || !user) throw new Error('source.host and source.user are required for the sftp adapter.');
  const target = `${user}@${host}`;
  const label = `SSH ${target}`;
  const remote = v => path.posix.join(root || '/', cleanVirtual(v));

  function run(script, input) {
    const args = ['-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-p', String(port),
      ...(identityFile ? ['-i', identityFile] : []), ...sshOptions, target, `/bin/sh -c ${sq(script)}`];
    return new Promise((resolve, reject) => {
      const child = spawn(sshBin, args, { stdio: ['pipe', 'pipe', 'pipe'] });
      const out = [], err = [];
      const timer = setTimeout(() => { child.kill('SIGKILL'); reject(badRequest(`SSH timed out after ${timeoutSec}s`, 504)); }, timeoutSec * 1000);
      child.stdout.on('data', d => out.push(d));
      child.stderr.on('data', d => err.push(d));
      child.on('error', e => { clearTimeout(timer); reject(badRequest(`Could not start ssh: ${e.message}`, 502)); });
      child.on('close', code => {
        clearTimeout(timer);
        resolve({ code, stdout: Buffer.concat(out), stderr: Buffer.concat(err).toString('utf8').trim() });
      });
      child.stdin.on('error', () => {});
      child.stdin.end(input || undefined);
    });
  }

  function fail(res, what) {
    if (res.code === 255) return badRequest(`SSH connection failed: ${res.stderr || 'no details'}`, 502);
    if (/No such file|cannot access|can't cd/i.test(res.stderr)) return badRequest(`${what} not found on ${host}.`, 404);
    return badRequest(`${what} failed on ${host}: ${res.stderr || `exit ${res.code}`}`, 502);
  }

  return {
    type: 'sftp',
    label,
    describe: () => ({ type: 'sftp', label, host, user, port, root: root || '/' }),

    async listFolders(virtual) {
      const res = await run(`cd -- ${sq(remote(virtual))} && find . -mindepth 1 -maxdepth 1 -type d -print0`);
      if (res.code !== 0) throw fail(res, `Folder ${cleanVirtual(virtual)}`);
      return res.stdout.toString('utf8').split('\0').filter(Boolean)
        .map(s => s.replace(/^\.\//, '')).sort((a, b) => a.localeCompare(b));
    },

    async readMappingTree(sourceVirtual) {
      const source = cleanVirtual(sourceVirtual);
      // One round trip: tar up every mapping.xml under the source and stream it back.
      const res = await run(`cd -- ${sq(remote(source))} && find . -type f -name mapping.xml -print0 | tar --null -T - -cf -`);
      if (res.code !== 0) throw fail(res, `Source folder ${source}`);
      const files = parseTar(res.stdout);
      if (files.length > MAX_FILES) throw badRequest(`More than ${MAX_FILES} mapping.xml files; pick a narrower source folder.`, 413);
      return groupByFolder(source, files.map(f => ({ rel: f.name, content: f.data.toString('utf8') })));
    },

    async writeFile(dirVirtual, name, buffer, { overwrite = false } = {}) {
      const dir = remote(dirVirtual);
      const file = path.posix.join(dir, name);
      const tmp = `${file}.wasvc-${Date.now()}.tmp`;
      const script = [
        `mkdir -p -- ${sq(dir)}`,
        overwrite ? 'true' : `if [ -e ${sq(file)} ]; then exit 17; fi`,
        `cat > ${sq(tmp)} || { rm -f -- ${sq(tmp)}; exit 1; }`,
        `mv -f -- ${sq(tmp)} ${sq(file)}`,
      ].join(' && ');
      const res = await run(script, buffer);
      if (res.code === 17) throw badRequest(`${name} already exists.`, 409);
      if (res.code !== 0) throw fail(res, `Writing ${name}`);
      return `${cleanVirtual(dirVirtual)}/${name}`.replace(/\/{2,}/g, '/');
    },
  };
}

module.exports = { createSftpAdapter, sq };
