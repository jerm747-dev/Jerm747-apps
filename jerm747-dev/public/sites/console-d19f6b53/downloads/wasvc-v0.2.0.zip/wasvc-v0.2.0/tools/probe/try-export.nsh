#!/bin/nsh
# WASVC: one-job export test (BSA 25.4, NSH Script Jobs).
#
# Exports ONE NSH Script Job to a NEW local folder so we can see exactly what
# an export produces (mapping.xml and anything else) and how long it takes.
# It only reads from BSA. Nothing in BSA is created, changed or deleted.
#
# Before running, acquire a session credential once with the same profile the
# console uses (it should prompt for your password):
#     blcred cred -acquire -profile "<profile>" -username <your user>
#
# Run from the Network Shell (NSH):
#     nsh try-export.nsh "<profile>" "<role>" "<job group path>" "<job name>" [output folder]
# Example:
#     nsh try-export.nsh "NonProd_BSA" "DEPLOYERADV_MW_CSW_NP_BL" \
#         "/Products/Middleware/WebSphere/Teams/CDTS/Build/DAIT/WAS Fixpack Upgrade/WAS Upgrade 9.0.5.29_r02" \
#         "Install_nd9.0.5.29_r02" /c/temp/wasvc-export-test
#
# Commands used (TrueSight Server Automation CLI 25.4):
#   NSH performance commands: blcli_setoption / blcli_connect / blcli_execute / blcli_storeenv
#   Job listAllByGroup <group>
#   NSHScriptJob getDBKeyByGroupAndName <group> <job>
#   ImportExport exportObject 111 <dbKey> <outputDir>     (111 = NSH Script Job)

if [ $# -lt 4 ]; then
  echo "Usage: nsh try-export.nsh <profile> <role> <job group path> <job name> [output folder]"
  exit 2
fi
PROFILE="$1"; ROLE="$2"; GROUP="$3"; JOB="$4"; OUT="${5:-./wasvc-export-test}"

# exportObject overwrites files in an existing folder, so insist on a new one
if [ -e "$OUT" ]; then
  echo "Output folder already exists: $OUT"
  echo "Pick a new folder name so nothing gets overwritten."
  exit 2
fi

fail() { echo "FAILED at: $1"; blcli_disconnect >/dev/null 2>&1; exit 1; }

START=$(date +%s)
echo "1/4 Connecting with profile '$PROFILE' and role '$ROLE'..."
blcli_setoption serviceProfileName "$PROFILE" || fail "setting profile"
blcli_setoption roleName "$ROLE"              || fail "setting role"
blcli_connect                                 || fail "connect (check the profile name and that blcred cred -acquire succeeded)"

echo "2/4 Jobs in the group:"
blcli_execute Job listAllByGroup "$GROUP"     || fail "listing the job group (check the group path)"
blcli_storeenv JOBS
echo "$JOBS" | sed 's/^/    /'

echo "3/4 Looking up '$JOB'..."
blcli_execute NSHScriptJob getDBKeyByGroupAndName "$GROUP" "$JOB" || fail "job lookup (check the job name)"
blcli_storeenv JOB_KEY

echo "4/4 Exporting to $OUT ..."
EXPORT_START=$(date +%s)
blcli_execute ImportExport exportObject 111 "$JOB_KEY" "$OUT" || fail "export"
EXPORT_END=$(date +%s)
blcli_disconnect

echo ""
echo "Export finished in $((EXPORT_END - EXPORT_START))s (whole script $((EXPORT_END - START))s)."
echo "Files written:"
find "$OUT" -type f | sed 's/^/    /'
if find "$OUT" -type f -name mapping.xml | grep -q .; then
  echo "mapping.xml found: the WASVC scan can read this export as-is."
else
  echo "No mapping.xml in this export. Send the file list above so the reader can be adjusted."
fi
