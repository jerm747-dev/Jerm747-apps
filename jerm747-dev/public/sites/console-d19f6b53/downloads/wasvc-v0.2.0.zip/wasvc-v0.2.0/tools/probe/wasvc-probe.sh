#!/bin/sh
# WASVC environment check (Linux/UNIX). READ-ONLY.
#
# Answers four questions for wiring the BladeLogic (blcli) source:
#   1. Where are blcli / blcred / nsh installed?
#   2. Which BSA version is installed?
#   3. Which authentication profile name(s) exist?
#   4. Is Node.js 18+ (or Java) available?
#
# What it does NOT do: log in, acquire credentials, read credential caches,
# contact any server, or change any file. Its only write is the report file.
#
# Usage:  sh wasvc-probe.sh [report-file]      (default: ./wasvc-probe-report.txt)
# Review the report before sharing it. Host names, IP addresses and your
# user name are masked automatically, but read it anyway.

REPORT="${1:-./wasvc-probe-report.txt}"
TMP="${TMPDIR:-/tmp}/wasvc-probe.$$"
: > "$TMP" || { echo "Cannot write temp file"; exit 1; }
trap 'rm -f "$TMP"' EXIT

say() { printf '%s\n' "$*" >> "$TMP"; }
hr()  { say ""; say "== $* =="; }

say "WASVC environment check (read-only)"
say "Run at: $(date -u '+%Y-%m-%d %H:%M UTC')"
say "OS:     $(uname -sr 2>/dev/null)"

# ---------------------------------------------------------------- 1. tools
hr "1. BladeLogic tools"
FOUND_BIN=""
INSTALL_DIRS=""
for t in blcli blcred nsh; do
  p=$(command -v "$t" 2>/dev/null)
  if [ -n "$p" ]; then
    say "  $t on PATH: $p"; FOUND_BIN="${FOUND_BIN:-$(dirname "$p")}"
    [ "$t" = blcli ] && INSTALL_DIRS="$(dirname "$(dirname "$p")")"     # .../NSH/bin/blcli -> .../NSH
  else say "  $t on PATH: not found"; fi
done

say "  Searching common install folders..."
for base in /opt/bmc/BladeLogic /opt/bmc/bladelogic /opt/bladelogic /usr/nsh /opt/BMC* ; do
  [ -d "$base" ] || continue
  # blcli normally sits in .../NSH/bin
  hits=$(find "$base" -maxdepth 4 -type f -name blcli 2>/dev/null)
  for h in $hits; do
    say "    blcli: $h"
    d=$(dirname "$(dirname "$h")")          # .../NSH
    INSTALL_DIRS="$INSTALL_DIRS $d"
    FOUND_BIN="${FOUND_BIN:-$(dirname "$h")}"
  done
done
[ -z "$INSTALL_DIRS" ] && [ -z "$FOUND_BIN" ] && say "    No blcli found. Is the BSA console/client installed on this machine?"

# ---------------------------------------------------------------- 2. version
hr "2. BSA version"
for d in $INSTALL_DIRS; do
  # Install path is usually .../BladeLogic/<version>/NSH
  v=$(basename "$(dirname "$d")")
  case "$v" in [0-9]*) say "  From install path: $v  ($d)";; esac
  for f in "$d/br/version" "$d/version" "$d/../version"; do
    [ -f "$f" ] && say "  $(basename "$f") file: $(head -n 3 "$f" | tr '\n' ' ')"
  done
done
say "  If nothing shows above: in the BSA console, open Help > About."

# ---------------------------------------------------------------- 3. profiles
hr "3. Authentication profiles"
[ -n "$BL_AUTH_PROFILE_NAME" ]  && say "  BL_AUTH_PROFILE_NAME is set: $BL_AUTH_PROFILE_NAME"
[ -n "$BL_AUTH_PROFILES_FILE" ] && say "  BL_AUTH_PROFILES_FILE is set: $BL_AUTH_PROFILES_FILE"
PROFILE_FILES=""
for c in "$BL_AUTH_PROFILES_FILE" $(for d in $INSTALL_DIRS; do echo "$d/br/authenticationProfiles.xml"; done); do
  [ -n "$c" ] && [ -f "$c" ] && PROFILE_FILES="$PROFILE_FILES
$c"
done
for home in "$HOME/.bladelogic" "$HOME/.BladeLogic" "$HOME/bladelogic"; do
  [ -d "$home" ] && PROFILE_FILES="$PROFILE_FILES
$(find "$home" -maxdepth 4 -type f -iname '*authenticationProfiles*.xml' 2>/dev/null)"
done
printf '%s\n' "$PROFILE_FILES" | while IFS= read -r f; do
  [ -n "$f" ] || continue
  say "  Profile file: $f"
  # Print names only (no hosts or other settings): name="..." attributes and <name>/<profile_name> elements
  names=$(grep -oE '(profile_?[Nn]ame|[Nn]ame)="[^"]*"|<(profile_?name|name)>[^<]*<' "$f" 2>/dev/null \
          | sed -E 's/.*="([^"]*)"/\1/; s/<[^>]*>([^<]*)</\1/' | sort -u)
  if [ -n "$names" ]; then printf '%s\n' "$names" | while IFS= read -r n; do say "    profile name candidate: $n"; done
  else say "    (no names recognized; open the file and look for the profile entries)"; fi
done
[ -z "$(printf '%s' "$PROFILE_FILES" | tr -d '\n')" ] && say "  No authenticationProfiles.xml found in the usual places."
say "  Reliable fallback: the BSA console login window shows the profile in its Authentication Profile list."

# ---------------------------------------------------------------- blcred usage (help text only)
hr "blcred usage (help text only, nothing is acquired)"
B=$(command -v blcred 2>/dev/null); [ -z "$B" ] && [ -n "$FOUND_BIN" ] && [ -x "$FOUND_BIN/blcred" ] && B="$FOUND_BIN/blcred"
if [ -n "$B" ]; then
  # No arguments: prints usage and exits. Limited to 25 lines.
  ( "$B" 2>&1 & pid=$!; ( sleep 15; kill $pid 2>/dev/null ) & wait $pid ) | head -n 25 | sed 's/^/  | /' >> "$TMP"
else
  say "  blcred not found."
fi

# ---------------------------------------------------------------- 4. runtimes
hr "4. Runtimes for the WASVC backend"
if command -v node >/dev/null 2>&1; then
  nv=$(node --version 2>/dev/null); major=$(printf '%s' "$nv" | sed -E 's/^v([0-9]+).*/\1/')
  if [ "${major:-0}" -ge 18 ] 2>/dev/null; then say "  Node.js: $nv  (OK, 18+ needed)"; else say "  Node.js: $nv  (too old, 18+ needed)"; fi
else
  say "  Node.js: not found  (WASVC backend needs Node 18+, or a Java port)"
fi
if command -v java >/dev/null 2>&1; then
  say "  Java:    $(java -version 2>&1 | grep -v '^Picked up' | head -n 1)"
else
  say "  Java:    not found on PATH"
fi

hr "Done"
say "Nothing was changed. Review this report before sharing it."

# Mask user name, IPv4 addresses and host names ending in common domain suffixes
U=$(id -un 2>/dev/null)
sed -E \
  -e "s/\b${U:-__nouser__}\b/<user>/g" \
  -e '/[Vv]ersion|Java:|install path/!s#(^|[^/\\0-9.])([0-9]{1,3}\.){3}[0-9]{1,3}\b#\1<ip>#g' \
  -e 's/\b[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.(com|net|org|corp|local|lan|int|intranet)\b/<host>/g' \
  "$TMP" > "$REPORT"
cat "$REPORT"
echo ""
echo "Report written to: $REPORT"
