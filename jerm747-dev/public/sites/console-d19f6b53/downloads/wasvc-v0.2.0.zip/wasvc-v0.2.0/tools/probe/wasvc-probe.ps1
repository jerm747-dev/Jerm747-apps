<#
  WASVC environment check (Windows). READ-ONLY.

  Answers four questions for wiring the BladeLogic (blcli) source:
    1. Where are blcli / blcred / nsh installed?
    2. Which BSA version is installed?
    3. Which authentication profile name(s) exist?
    4. Is Node.js 18+ (or Java) available?

  What it does NOT do: log in, acquire credentials, read credential caches,
  contact any server, or change any file. Its only write is the report file.

  Usage (PowerShell):   .\wasvc-probe.ps1 [-Report <path>]
  Default report: .\wasvc-probe-report.txt
  If script execution is blocked by policy, do NOT bypass it. Use the manual
  checks in README.md in this folder instead.

  Review the report before sharing it. Host names, IP addresses and your user
  name are masked automatically, but read it anyway.
#>
param([string]$Report = ".\wasvc-probe-report.txt")

$ErrorActionPreference = 'SilentlyContinue'
$lines = New-Object System.Collections.Generic.List[string]
function Say([string]$s) { $lines.Add($s) | Out-Null }
function Hr([string]$s)  { Say ""; Say "== $s ==" }

Say "WASVC environment check (read-only)"
Say ("Run at: " + (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm") + " UTC")
Say ("OS:     " + [System.Environment]::OSVersion.VersionString)
Say ("PowerShell: " + $PSVersionTable.PSVersion.ToString())

# ---------------------------------------------------------------- 1. tools
Hr "1. BladeLogic tools"
$installDirs = New-Object System.Collections.Generic.List[string]
$binDir = $null
foreach ($t in @('blcli', 'blcred', 'nsh')) {
  $cmd = Get-Command $t -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) {
    Say "  $t on PATH: $($cmd.Source)"
    if (-not $binDir) { $binDir = Split-Path $cmd.Source -Parent }
    if ($t -eq 'blcli') { $installDirs.Add((Split-Path (Split-Path $cmd.Source -Parent) -Parent)) }
  } else {
    Say "  $t on PATH: not found"
  }
}

Say "  Searching common install folders..."
$bases = @()
foreach ($pf in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, 'C:\BMC', 'D:\BMC', 'D:\Program Files')) {
  if ($pf) {
    foreach ($sub in @('BMC Software', 'BladeLogic')) {
      $p = Join-Path $pf $sub
      if ((Test-Path $p) -and ($bases -notcontains $p)) { $bases += $p }
    }
  }
}
foreach ($b in $bases) {
  # blcli normally sits in ...\NSH\bin ; limit the depth so this stays quick
  $hits = Get-ChildItem -Path $b -Filter 'blcli*.exe' -Recurse -Depth 4 -File -ErrorAction SilentlyContinue
  if (-not $hits) { $hits = Get-ChildItem -Path $b -Filter 'blcli*' -Recurse -Depth 5 -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match '\\NSH\\bin\\' } }
  foreach ($h in $hits) {
    Say "    $($h.Name): $($h.FullName)"
    $nsh = Split-Path (Split-Path $h.FullName -Parent) -Parent
    if ($installDirs -notcontains $nsh) { $installDirs.Add($nsh) }
    if (-not $binDir) { $binDir = Split-Path $h.FullName -Parent }
  }
}
if ($installDirs.Count -eq 0 -and -not $binDir) { Say "    No blcli found. Is the BSA console/client installed on this machine?" }

# ---------------------------------------------------------------- 2. version
Hr "2. BSA version"
foreach ($d in $installDirs) {
  # Install path is usually ...\BladeLogic\<version>\NSH
  $v = Split-Path (Split-Path $d -Parent) -Leaf
  if ($v -match '^\d') { Say "  From install path: $v  ($d)" }
  foreach ($exe in @('bin\blcli.exe', 'bin\blcred.exe', 'bin\nsh.exe')) {
    $f = Join-Path $d $exe
    if (Test-Path $f) {
      $vi = (Get-Item $f).VersionInfo
      if ($vi.ProductVersion) { Say "  $exe product version: $($vi.ProductVersion)" }
    }
  }
}
Say "  If nothing shows above: in the BSA console, open Help > About."

# ---------------------------------------------------------------- 3. profiles
Hr "3. Authentication profiles"
if ($env:BL_AUTH_PROFILE_NAME)  { Say "  BL_AUTH_PROFILE_NAME is set: $env:BL_AUTH_PROFILE_NAME" }
if ($env:BL_AUTH_PROFILES_FILE) { Say "  BL_AUTH_PROFILES_FILE is set: $env:BL_AUTH_PROFILES_FILE" }
$profileFiles = @()
if ($env:BL_AUTH_PROFILES_FILE -and (Test-Path $env:BL_AUTH_PROFILES_FILE)) { $profileFiles += $env:BL_AUTH_PROFILES_FILE }
foreach ($d in $installDirs) {
  $f = Join-Path $d 'br\authenticationProfiles.xml'
  if (Test-Path $f) { $profileFiles += $f }
}
foreach ($u in @("$env:APPDATA\BladeLogic", "$env:LOCALAPPDATA\BladeLogic", "$env:USERPROFILE\.bladelogic", "$env:USERPROFILE\BladeLogic")) {
  if ($u -and (Test-Path $u)) {
    Get-ChildItem -Path $u -Filter '*authenticationProfiles*.xml' -Recurse -Depth 4 -File -ErrorAction SilentlyContinue |
      ForEach-Object { $profileFiles += $_.FullName }
  }
}
$profileFiles = $profileFiles | Select-Object -Unique
foreach ($f in $profileFiles) {
  Say "  Profile file: $f"
  # Names only (no hosts or other settings): name="..." attributes and <name>/<profile_name> elements
  $text = Get-Content -Path $f -Raw
  $names = @()
  foreach ($m in [regex]::Matches($text, '(?i)\b(?:profile_?name|name)="([^"]*)"')) { $names += $m.Groups[1].Value }
  foreach ($m in [regex]::Matches($text, '(?i)<(?:profile_?name|name)>([^<]*)<')) { $names += $m.Groups[1].Value }
  $names = $names | Where-Object { $_ } | Sort-Object -Unique
  if ($names) { foreach ($n in $names) { Say "    profile name candidate: $n" } }
  else { Say "    (no names recognized; open the file and look for the profile entries)" }
}
if (-not $profileFiles) { Say "  No authenticationProfiles.xml found in the usual places." }
Say "  Reliable fallback: the BSA console login window shows the profile in its Authentication Profile list."

# ---------------------------------------------------------------- blcred usage (help text only)
Hr "blcred usage (help text only, nothing is acquired)"
$blcred = Get-Command blcred -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source
if (-not $blcred -and $binDir) {
  $c = Join-Path $binDir 'blcred.exe'
  if (Test-Path $c) { $blcred = $c }
}
if ($blcred) {
  # No arguments: prints usage and exits. Stopped after 15 seconds; limited to 25 lines.
  $tmpOut = [System.IO.Path]::GetTempFileName()
  $tmpErr = [System.IO.Path]::GetTempFileName()
  $proc = Start-Process -FilePath $blcred -NoNewWindow -PassThru -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr
  if (-not $proc.WaitForExit(15000)) { $proc.Kill() }
  $help = @(Get-Content $tmpOut) + @(Get-Content $tmpErr) | Select-Object -First 25
  foreach ($l in $help) { Say "  | $l" }
  Remove-Item $tmpOut, $tmpErr -Force
} else {
  Say "  blcred not found."
}

# ---------------------------------------------------------------- 4. runtimes
Hr "4. Runtimes for the WASVC backend"
$node = Get-Command node -ErrorAction SilentlyContinue | Select-Object -First 1
if ($node) {
  $nv = (& $node.Source --version) 2>$null
  $major = 0
  if ($nv -match '^v(\d+)') { $major = [int]$Matches[1] }
  if ($major -ge 18) { Say "  Node.js: $nv  (OK, 18+ needed)" } else { Say "  Node.js: $nv  (too old, 18+ needed)" }
} else {
  Say "  Node.js: not found  (WASVC backend needs Node 18+, or a Java port)"
}
$java = Get-Command java -ErrorAction SilentlyContinue | Select-Object -First 1
if ($java) {
  $jv = (& $java.Source -version 2>&1) | ForEach-Object { "$_" } | Where-Object { $_ -notmatch '^Picked up' } | Select-Object -First 1
  Say "  Java:    $jv"
} else {
  Say "  Java:    not found on PATH"
}

Hr "Done"
Say "Nothing was changed. Review this report before sharing it."

# Mask user name, IPv4 addresses and host names ending in common domain suffixes
$out = $lines | ForEach-Object {
  $s = $_
  if ($env:USERNAME) { $s = $s -replace ('(?i)\b' + [regex]::Escape($env:USERNAME) + '\b'), '<user>' }
  # Version numbers like 8.9.03.001 look like IPs, so leave version lines and install paths alone
  if ($s -notmatch '(?i)version|Java:|install path') { $s = $s -replace '(?<![\\/\d.])\b(\d{1,3}\.){3}\d{1,3}\b', '<ip>' }
  $s = $s -replace '(?i)\b[a-z0-9-]+(\.[a-z0-9-]+)*\.(com|net|org|corp|local|lan|int|intranet)\b', '<host>'
  $s
}
$out | Set-Content -Path $Report -Encoding UTF8
$out | ForEach-Object { Write-Host $_ }
Write-Host ""
Write-Host "Report written to: $((Resolve-Path $Report).Path)"
