# WASVC environment check

A one-time, **read-only** check to run on a machine that has the BSA console installed. It collects what's needed to wire the BladeLogic (`blcli`) source:

1. **Where `blcli`, `blcred` and `nsh` are installed** (usually `…\BladeLogic\<version>\NSH\bin`)
2. **The BSA version**
3. **The authentication profile name(s)** the console uses
4. **Whether Node.js 18+ is available** (and Java, as a fallback option)

## What it does and doesn't do

- **Does:** look at `PATH` and the usual install folders, read profile **names** from `authenticationProfiles.xml`, print `blcred`'s built-in usage text, and check the Node and Java versions.
- **Doesn't:** log in, acquire or read credentials, contact any server, or change anything. Its only write is the report file.
- **Masks** your user name, IP addresses and host names (`*.com`, `*.corp`, `*.local`, and so on) in the report. Read the report before sharing it anyway.

## Run it

**Windows (PowerShell):**
```powershell
cd <wasvc>\tools\probe
.\wasvc-probe.ps1
```
**Linux:**
```sh
sh tools/probe/wasvc-probe.sh
```
Both write `wasvc-probe-report.txt` in the current folder. Use `-Report <path>` (Windows) or a first argument (Linux) to write it somewhere else.

**If PowerShell scripts are blocked by policy, don't bypass the policy.** Use the manual checks below instead. They give the same answers.

## Manual checks (no script)

| Question | How |
|---|---|
| Where is blcli? | Open **Command Prompt** and run `where blcli` and `where blcred`. If nothing comes back, look in `C:\Program Files\BMC Software\BladeLogic\<version>\NSH\bin`. |
| BSA version | In the BSA console, open **Help → About**. The version is also the folder name in the path above. |
| Profile name | On the BSA console **login window**, the **Authentication Profile** list shows it. Names are case-sensitive. |
| Node.js | `node --version` in Command Prompt. 18 or higher is needed. |
| Java | `java -version`. This only matters if Node isn't allowed and the backend is ported to Java. |

## One-job export test (`try-export.nsh`)

After the check above, this confirms the full blcli path works with one real job. The WAS fixpack jobs are **NSH Script Jobs** (object type `111`), which BSA can export.

1. In a command prompt, get a session credential with the console's profile. It should prompt for your password:
   `blcred cred -acquire -profile "<profile>" -username <your user>`
2. Open the Network Shell (NSH) and run:
   `nsh try-export.nsh "<profile>" "<role>" "<job group path>" "<job name>" /c/temp/wasvc-export-test`

The script connects once, lists the jobs in the group, looks up the one job, exports it to the **new** folder you name, and reports the files written and how long the export took. It refuses to use a folder that already exists, because the export would overwrite it. It only reads from BSA.

What it tells us: whether the profile and role work outside the console, whether the export contains `mapping.xml` in the layout WASVC reads, and how long a single export takes through blcli compared with the console.

## What happens next

With these four answers, the `blcli` source can be written against the real commands. It will:
- reuse a session credential from `blcred cred -acquire` with the console's profile, so WASVC never handles passwords;
- pass the deployer role on every call;
- keep one BSA session open for the whole run, using the NSH performance commands, instead of starting `blcli` once per job.
