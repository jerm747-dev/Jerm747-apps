'use strict';
// Writes made-up job folders with mapping.xml files into ./sample-jobs for local testing.
// Dummy data only: no real job names, servers or groups.
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..', 'sample-jobs',
  'Products/Middleware/WebSphere/Teams/CDTS/Build/DAIT/WAS Fixpack Upgrade');

const entry = (type, name, gid, group) => `  <grouped_object_mapping>
    <source_object>
      <object_type>${type}</object_type>
      <object_name>${name}</object_name>
      <group_id>${gid}</group_id>
    </source_object>${group == null ? '' : `
    <containing_group>${group}</containing_group>`}
  </grouped_object_mapping>`;
const mapping = (...e) => `<?xml version="1.0" encoding="UTF-8"?>\n<mapping>\n${e.join('\n')}\n</mapping>\n`;
const VIRTUAL_BASE = '/Products/Middleware/WebSphere/Teams/CDTS/Build/DAIT/WAS Fixpack Upgrade';
const depot = v => entry('Depot Software', `${v}.tar.gz`, 2001, '/Depot/Middleware/WebSphere/Packages');
const job = v => entry('NSH Script Job', `Install_${v}`, 3001, '/Jobs/Middleware/WebSphere/Fixpack');
// Real-style: an NSH Script Job named with a bare version, grouped under its version folder
const stageJob = (folder, bare, sub) => entry('NSH Script Job', `StageWAS${bare}`, 3101, `${VIRTUAL_BASE}/${folder}/${sub}`);
const stage = entry('NSH Script', 'StageWAS8.5.5', 4001,
  '/Products/Middleware/Websphere/Teams/eComm/NextGen/sharedscripts/WAS_WEB/nd8.5.5');

const versions = {
  'WAS Upgrade 9.0.5.27_r01': { cur: 'nd9.0.5.27_r01', old: 'nd9.0.5.27', ihs: 'ihs_plg_9.0.5.27_r01' },
  'WAS Upgrade 9.0.5.28_r03': { cur: 'nd9.0.5.28_r03', old: 'nd9.0.5.27_r01', ihs: 'ihs_plg_9.0.5.28_r03' },
  'WAS Upgrade 9.0.5.29_r02': { cur: 'nd9.0.5.29_r02', old: 'nd9.0.5.28_r03', ihs: 'ihs_plg_9.0.5.28_r03' },
};

let count = 0;
for (const [folder, v] of Object.entries(versions)) {
  const bare = v.cur.replace(/^nd/, '');
  const files = {
    'AppA/DEV/mapping.xml': mapping(depot(v.cur), job(v.cur), stageJob(folder, bare, 'AppA/DEV'), stage),
    'AppA/UAT/mapping.xml': mapping(depot(v.old), depot(v.ihs), job(v.old)),
    'AppB/DEV/mapping.xml': mapping(depot('nd9.0.5.27_r01'), job(v.cur), stageJob(folder, bare, 'AppB/DEV')),
    'AppB/SIT/mapping.xml': mapping(depot('nd8.5.5'), job('nd8.5.5')),
    'AppC/PROD-STAGE/mapping.xml': mapping(entry('NSH Script Job', 'Prep_Servers', 5001, null)),
  };
  for (const [rel, content] of Object.entries(files)) {
    const full = path.join(BASE, folder, rel);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
    count++;
  }
}
console.log(`Wrote ${count} sample mapping.xml files under ${path.relative(process.cwd(), BASE)}`);
