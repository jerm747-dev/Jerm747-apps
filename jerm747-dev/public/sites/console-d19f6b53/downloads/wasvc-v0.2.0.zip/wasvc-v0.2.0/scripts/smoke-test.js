'use strict';
// Starts the server on a spare port against ./sample-jobs and checks every API route.
// Run with: npm test
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createServer } = require('../src/server');

(async () => {
  const sampleRoot = path.join(__dirname, '..', 'sample-jobs');
  if (!fs.existsSync(sampleRoot)) require('./make-samples');
  // Work on a copy so the test never touches your sample folder
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'wasvc-test-'));
  fs.cpSync(sampleRoot, tmp, { recursive: true });

  const jobsBase = '/Products/Middleware/WebSphere/Teams/CDTS/Build/DAIT/WAS Fixpack Upgrade';
  const cfg = { host: '127.0.0.1', port: 0, jobsBase, maxUploadMB: 1, source: { type: 'local', root: tmp } };
  const server = createServer(cfg);
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  cfg.port = server.address().port;
  const server2 = createServer(cfg);                 // rebuild so the Host check knows the real port
  server.close();
  await new Promise(r => server2.listen(cfg.port, '127.0.0.1', r));
  const base = `http://127.0.0.1:${cfg.port}`;
  const j = async (p, o) => { const r = await fetch(base + p, o); return { status: r.status, body: await r.json().catch(() => null) }; };

  try {
    // One version everywhere: package.json, the API, the UI and the changelog
    const { version } = require('../package.json');
    let r = await j('/api/health');
    assert.equal(r.status, 200); assert.equal(r.body.source.type, 'local');
    assert.equal(r.body.version, version, 'API reports the package.json version');
    const ui = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
    assert.ok(ui.includes(`const WASVC_VERSION = '${version}';`), `public/index.html WASVC_VERSION must be ${version}`);
    const log = fs.readFileSync(path.join(__dirname, '..', 'CHANGELOG.md'), 'utf8');
    assert.ok(log.includes(`## ${version}`), `CHANGELOG.md needs a "## ${version}" entry`);
    const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
    assert.ok(readme.includes(`**Version ${version}**`), `README.md Version line must say ${version}`);

    r = await j(`/api/folders?path=${encodeURIComponent(jobsBase)}`);
    assert.deepEqual(r.body.folders, ['WAS Upgrade 9.0.5.27_r01', 'WAS Upgrade 9.0.5.28_r03', 'WAS Upgrade 9.0.5.29_r02']);

    const source = `${jobsBase}/WAS Upgrade 9.0.5.29_r02`;
    r = await j('/api/read', { method: 'POST', body: JSON.stringify({ source }) });
    assert.equal(r.status, 200); assert.equal(r.body.jobs.length, 5);
    assert.equal(r.body.jobs[0].folder, `${source}/AppA/DEV`);
    assert.equal(r.body.jobs[0].files[0].path, 'AppA/DEV/mapping.xml');

    r = await j('/api/read', { method: 'POST', body: JSON.stringify({ source: `${jobsBase}/../../../../etc` }) });
    assert.equal(r.status, 400, 'path traversal must be refused');
    r = await j('/api/read', { method: 'POST', body: JSON.stringify({ source: `${jobsBase}/Nope` }) });
    assert.equal(r.status, 404);

    const zip = Buffer.from([0x50, 0x4b, 0x05, 0x06, ...new Array(18).fill(0)]);    // empty ZIP
    const up = (name, overwrite = '0', body = zip) =>
      j(`/api/upload?dir=${encodeURIComponent(jobsBase)}&name=${encodeURIComponent(name)}&overwrite=${overwrite}`, { method: 'POST', body });
    r = await up('test.zip'); assert.equal(r.status, 201);
    r = await up('test.zip'); assert.equal(r.status, 409, 'no silent overwrite');
    r = await up('test.zip', '1'); assert.equal(r.status, 201);
    r = await up('../evil.zip'); assert.equal(r.status, 400);
    r = await up('notes.txt'); assert.equal(r.status, 400);
    r = await up('bad.zip', '0', Buffer.from('hello')); assert.equal(r.status, 400);
    assert.ok(fs.existsSync(path.join(tmp, jobsBase, 'test.zip')));
    assert.ok(!fs.readdirSync(path.join(tmp, jobsBase)).some(f => f.endsWith('.tmp')), 'no temp files left');

    r = await j('/api/read', { method: 'POST', headers: { Origin: 'http://evil.example' }, body: JSON.stringify({ source }) });
    assert.equal(r.status, 403, 'cross-origin POST refused');

    console.log('All smoke tests passed.');
  } finally {
    server2.close();
    fs.rmSync(tmp, { recursive: true, force: true });
  }
})().catch(e => { console.error(e); process.exit(1); });
