# WASVC: WebSphere Application Server Version Control

**Version 0.2.0** · see [CHANGELOG.md](CHANGELOG.md)

Part of the **Consumer Application Console**. WASVC reads BladeLogic (BSA) job exports, finds every WebSphere and IHS plugin version in their `mapping.xml` files, normalizes them to the approved target in one pass, and packages the result for team review and import.

The console also includes the **EM Validation Tool (EMVT)**, which follows deployments as they happen. See [EMVT](#emvt-em-validation-tool-preview) below.

## Why it exists

Updating job versions by hand means exporting each job (about 5 minutes), editing `mapping.xml` in a text editor, and importing it back (about 5 more minutes). Across many jobs and environments, the clicking costs about as much time as the change saves, and hand edits are easy to get wrong.

WASVC replaces that with: **export once → scan and normalize everything together, with a review → import once.**

## Quick start

Requires **Node.js 18 or newer**. There are no third-party packages, so no `npm install` is needed.

```sh
npm run samples   # creates example job folders in ./sample-jobs
npm start         # serves the console at http://127.0.0.1:7474
npm test          # checks every API route against a temporary copy of the samples
```

Open **http://127.0.0.1:7474**. The badge at the top right shows which source is connected. You can also open `public/index.html` directly as a file to try the screens on built-in example data; it never contacts a server.

## Walkthrough

| Step | What you do | What WASVC does |
|---|---|---|
| **1 · Connect** | Enter the BSA server, user, domain, password and role (default `DEPLOYERADV_MW_CSW_NP_BL`). | Checks the backend is reachable. The password is never stored. |
| **2 · Job Source** | Pick the source job folder. Set the output folder and ZIP name, plus any **protected files** and **protected strings**. | Fills the output folder with the source folder's parent. |
| **3 · Scan Versions** | Click **Scan**. | Reads every `mapping.xml` under the source and lists each version found, with its folder, job name, key, value and line number. |
| **4 · Select & Normalize** | Mark each folder **Normalize**, **Keep** or **Remove**. Set the target version for WebSphere ND and for the IHS plugin, and choose which other versions to replace or allow. Optionally turn on **Retarget job group** and/or **Rename versions in job names**. Tick **Force normalization**, then **Apply**. | Rewrites versions in an in-memory copy only. Live jobs are never touched. |
| **5 · Validate & Review** | Click **Validate**, read the before/after view of the sample files, and confirm the review. | Checks that every file is well-formed XML and has the expected mapping elements. |
| **6 · Package** | Click **Build ZIP**, then **Download** or **Send to output directory**. | Builds the ZIP with `WASVC_MANIFEST.txt`, which lists the targets, protections, folder actions and every changed line. It never overwrites an existing file unless **Replace** is ticked. |

Every step is reachable from the bar across the top. A step whose earlier work isn't done shows a link back to the step it needs.

### Normalization rules

- **Versions matched:** `nd8.5.5`, `nd9.0.5.27`, `nd9.0.5.27_r02`, `ihs_plg_9.0.5.28_r03`, including inside names such as `Install_nd9.0.5.28_r03` and `nd9.0.5.28_r03.tar.gz`.
- **Families:** WebSphere ND (`nd…`) and the IHS plugin (`ihs_plg_…`) each have their own target and approved list. The prefix never changes.
- **Protected files** (default `StageWAS8.5.5.nsh`) match by file name as a whole word. Any `<grouped_object_mapping>` block that references one is left unchanged.
- **Protected strings** (for example `Install WAS 8.5.5`) match ignoring case. Any line that contains one is left unchanged; the rest of the file is still normalized.
- **Retarget job group** (optional, off by default): rewrites the start of each `<containing_group>` path from the current group to a new one, for example `…/WAS Upgrade 9.0.5.29_r02/CMA/CMA TT` → `…/WAS Upgrade 9.0.5.30_r01/CMA/CMA TT`. This decides where the import places each job. Paths outside the current group are untouched. The new group is suggested from the WebSphere ND target.
- **Rename versions in job names** (optional, off by default): swaps a bare version inside *job* `<object_name>` entries only, for example `StageWAS9.0.5.29_r02` → `StageWAS9.0.5.30_r01`. Scripts, depot packages and `nd…`/`ihs_plg_…` versions are not affected by this option. Test it with a one-job import first, since BSA may match exported objects by their original name.
- **Folder actions:** *Normalize* rewrites versions. *Keep* includes the folder as-is. *Remove* leaves it out of the ZIP and never deletes anything on a server.
- Changing a protection list after a scan clears the scan, so results always match the lists in effect.

## Before importing a package

These steps happen in BSA or on the WASVC host. WASVC does not do them.

1. **The target version's packages must already be in the BSA depot.** Changing `nd9.0.5.28_r03.tar.gz` to `nd9.0.5.29_r02.tar.gz` in `mapping.xml` tells the import to link to the `nd9.0.5.29_r02` package. If that `.tar.gz` (or the matching `ihs_plg_…tar.gz`) isn't in the depot, the import fails.
2. **Import into a new version job group, and create it first.** BSA import adds new objects instead of overwriting existing jobs. If **Retarget job group** is on, the new group (for example `…/WAS Upgrade 9.0.5.30_r01` and its subgroups such as `CMA/CMA TT`) must already exist in BSA.
3. **If job names were renamed**, import one job first and confirm BSA accepts the new name before importing the rest.
4. **Have the team review `WASVC_MANIFEST.txt`** in the package before importing.
5. **Roles:** export and import permissions are required. The deployer role already has both.

## Configuration

Copy `wasvc.config.example.json` to `wasvc.config.json`, or point the `WASVC_CONFIG` environment variable at another file. `wasvc.config.json` is git-ignored.

| Key | Default | Meaning |
|---|---|---|
| `host` | `127.0.0.1` | Interface to listen on. The default is local only. |
| `port` | `7474` | Port. The `PORT` environment variable overrides it. |
| `jobsBase` | `/Products/…/WAS Fixpack Upgrade` | Folder whose subfolders appear in the **Source folder** list. |
| `maxUploadMB` | `50` | Largest ZIP that **Send to output directory** accepts. |
| `source` | `local` | Where job files come from (see below). |

### Sources

Every source supports the same actions: list folders, read every `mapping.xml` under a folder, and write the package. The UI works the same whichever one is configured.

**`local`**: exported job folders on the WASVC host. A path such as `/Products/...` maps to `<root>/Products/...`.
```json
"source": { "type": "local", "root": "D:/wasvc/exports" }
```

**`sftp`**: exported job folders on a server reachable over SSH. Uses the system `ssh` client with **key-based login only**, so no passwords pass through WASVC. Host keys are verified, so connect once with `ssh user@host` to trust a new server. The server needs `sh`, `find` and `tar`.
```json
"source": { "type": "sftp", "host": "jobs-server.example.com", "user": "svc_wasvc", "port": 22,
            "identityFile": "~/.ssh/id_ed25519", "root": "" }
```
`root` is prefixed to every path. Leave it empty to use absolute paths as-is.

**`blcli`**: direct to BladeLogic. **Not wired yet.** See the next section.

## BladeLogic (blcli) integration: what's needed

The `blcli` source would export a job group, normalize it, and import the result with no manual export or import steps. To build and run it:

- **Where it runs:** on a machine with the **BSA console (RCP client)** installed, because that install provides the Network Shell (NSH), `blcli` and `blcred`. They're usually under `…\BMC Software\BladeLogic\<version>\NSH\bin` on Windows or `/opt/bmc/BladeLogic/<version>/NSH/bin` on Linux. Check the actual location with `where blcli` or `which blcli`. Node.js 18+ is also needed on the same machine.
- **Login:** an authentication profile whose name matches the one in the console (names are case-sensitive), with a session credential acquired through `blcred cred -acquire`. WASVC should reuse that session credential instead of handling passwords.
- **Role:** the deployer role, passed to every call.
- **Speed:** each standalone `blcli` call starts a JVM and logs in. The NSH performance commands (`blcli_setoption`, `blcli_connect`, `blcli_execute`) keep one session open, which matters when many jobs are processed.
- **Version in use:** Server Automation Console **25.4.00.52**. Use the [TrueSight Server Automation CLI 25.4 reference](https://docs.bmc.com/xwiki/bin/view/Automation-DevSecOps/Server-Automation/TrueSight-Server-Automation-Command-Line-Interface/TrueSight-Server-Automation-Command-Line-Interface-25-4/).
- **Export is one object per call:** `blcli ImportExport exportObject <objectType> <DBKey> <outputDir>`. The DBKey is looked up first, by group and name. NSH Script Jobs are object type `111`. If the output directory already has files, the call overwrites them. To export a job group, WASVC lists the jobs in the group and exports each one inside a single session.
- **Job type:** the WAS fixpack jobs are **NSH Script Jobs** (type `111`), which BSA can export. (BSA excludes *Patching*, *Provision* and *Virtual Guest* jobs from export.)
- **Lookups:** `Job listAllByGroup <group>` lists a group's jobs, and `NSHScriptJob getDBKeyByGroupAndName <group> <job>` returns the key for export.
- **Import** signatures (`ImportExport importObject`) must be confirmed in the 25.4 reference before wiring.

**Environment check:** `tools/probe/` has a one-time, read-only script (`wasvc-probe.ps1` for Windows, `wasvc-probe.sh` for Linux). Run it on a machine with the BSA console installed. It reports where `blcli` is installed, the BSA version, the authentication profile names, and the Node and Java versions, with host names and IP addresses masked. It never logs in or changes anything. `tools/probe/README.md` also lists manual checks that give the same answers without running a script. `tools/probe/try-export.nsh` then exports a single job to a new local folder, to confirm the export layout and timing. It reads only and changes nothing in BSA.

## EMVT: EM Validation Tool (preview)

EMVT watches known apps and follows each deployment as it happens. In this release it runs on **simulated activity**: the stage logic and percentages are real, and the file changes are generated. The backend folder watcher is the next step.

- **Watch list:** a JSON file of apps, each with its server type (Tomcat, JBoss, WebSphere), host, SSH user, folder to watch, EAR/WAR, and known size. Use **Add watch folder** to add apps, **Save watch list** to download the JSON (passwords are never written), and **Load watch list** to open one.
- **Stages:** Watching → Activity detected (files changing) → Deploying (the EAR/WAR changed, or a JBoss `.isdeploying` marker) → Settling (changes stopped) → **Deployed**, or **Failed** (JBoss `.failed`) / **Stalled** (stopped under 50%).
- **Progress:** the share of the app rewritten since the deployment started, so a same-size redeploy still runs 0–100%. Growth past the known size shows as **100% + X MB**. After a deployment, **Accept as the new baseline** updates the known size.
- **Recent activity:** every step from every app, newest first, filtered to the last 15 minutes, hour, 24 hours, or all.
- **Today's tickets:** add the day's Jira tickets (ID, title, link, environment, apps). Each ticket rolls up its apps' deployments into one status, unlocks **Deployment validated** once every app is deployed, and builds a plain-text **Jira update** to copy into the ticket. A ticket environment that doesn't match an app's environment is flagged. Set the **ticket link format** (e.g. `https://jira.example.com/browse/{id}`) so IDs become links.

Watch list format:
```json
{
  "watchlistVersion": 1, "pollSeconds": 10, "quietSeconds": 60,
  "ticketUrlTemplate": "https://jira.example.com/browse/{id}",
  "apps": [
    { "id": "orders-web", "name": "Orders Web", "env": "UAT", "server": "tomcat",
      "host": "app-server-01", "port": 22, "user": "svc_emvt", "auth": "key",
      "path": "/opt/tomcat/webapps/orders", "artifact": "/opt/tomcat/webapps/orders.war",
      "baselineBytes": 184549376 }
  ]
}
```

## API

| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | `/api/health` | | Active source and `jobsBase` |
| GET | `/api/folders` | `?path=/Products/...` | Subfolder names |
| POST | `/api/read` | `{ "source": "/Products/.../WAS Upgrade 9.0.5.29_r02" }` | `{ jobs: [{ folder, files: [{ path, content }] }] }` |
| POST | `/api/upload` | `?dir=…&name=x.zip&overwrite=0\|1`; body is the ZIP bytes | `201 { path }`, or `409` if the file exists and `overwrite=0` |

## Security

- Listens on `127.0.0.1` only unless `host` is changed.
- Every path is resolved inside the configured root, and `..` is refused.
- Uploads must be real ZIP files with a `.zip` name. Each upload is written to a temporary file and then moved into place.
- Requests with an unexpected `Host` header or a cross-site `Origin` are refused.
- Passwords entered in the UI are never stored or logged.

## Troubleshooting

| Symptom | Check |
|---|---|
| Badge says *Sample data (no backend)* | Open the console from `http://127.0.0.1:7474`, not as a file, and confirm `npm start` is running. |
| *Folder not found* on Load | `jobsBase` in the config, and that the folder exists under the source `root`. |
| *SSH connection failed* | Run `ssh user@host` by hand. A key or host-key prompt there means it isn't set up yet. |
| *already exists* on Send | Tick **Replace the file**, or change the ZIP name. |
| A file shows *Invalid* XML | Open it from the review step. That file must be fixed before packaging. |

## Status

| Area | State |
|---|---|
| UI: all six steps | Done |
| Scan, normalize, protections, review, manifest, ZIP | Done and tested |
| Backend: `local` source | Done and tested |
| Backend: `sftp` source | Done; tested against a simulated SSH server |
| Backend: `blcli` source | Not started; needs the details above |
| EMVT screens (watch list, stages, recent activity, tickets) | Done; runs on simulated activity |
| EMVT backend folder watcher + Jira title lookup | Planned |
| React/NPM port of the UI | Planned; the logic is already split into plain functions so it can move into components |

## Versioning

WASVC uses semantic versioning (**MAJOR.MINOR.PATCH**). PATCH is for fixes, MINOR for new features, and 1.0.0 for the first team-approved release. The running version appears in the sidebar, in `/api/health`, in every `WASVC_MANIFEST.txt`, and in the server's startup line.

To release a new version, update all four places, then run `npm test`. It fails if any of them disagree.
1. `"version"` in `package.json`
2. `WASVC_VERSION` in `public/index.html`
3. A new `## x.y.z` entry at the top of `CHANGELOG.md`
4. The **Version** line at the top of this README

## Project layout

```
CHANGELOG.md               version history
public/index.html          console UI (single file)
src/server.js              HTTP server and API
src/config.js              configuration loading
src/paths.js               path cleaning and root containment
src/tar.js                 tar reader used by the sftp source
src/adapters/local.js      local folder source
src/adapters/sftp.js       SSH source
src/adapters/blcli.js      BladeLogic source (placeholder)
scripts/make-samples.js    example job folders
scripts/smoke-test.js      API tests
tools/probe/               read-only environment check for the blcli source (Windows + Linux)
```

---
Author: Jeremy Currence
