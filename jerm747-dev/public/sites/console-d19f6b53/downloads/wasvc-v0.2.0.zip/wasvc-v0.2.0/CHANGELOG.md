# Changelog

All notable changes to WASVC. Versions follow [semantic versioning](https://semver.org): **MAJOR.MINOR.PATCH**.

- **PATCH** (0.1.**1**): fixes that don't change how the tool is used.
- **MINOR** (0.**2**.0): new features or options.
- **MAJOR** (**1**.0.0): first team-approved release, then any change that breaks existing configs or workflows.

Until 1.0.0, the tool is in active development and testing.

## 0.2.0 (2026-11-09)

Adds the **EM Validation Tool (EMVT)** to the console, as a preview running on simulated activity. EMVT is versioned separately inside the console (EMVT v0.4.1).

**EMVT (preview)**
- Watch list of known apps (JSON) for Tomcat, JBoss and WebSphere, with **Add watch folder** (host or IP, SSH port, user, SSH key or session-only password, folder, EAR/WAR, known size). Saved watch lists never contain passwords.
- Deployment stages: Watching → Activity detected → Deploying → Settling → Deployed, or Failed / Stalled. JBoss deployment markers (`.isdeploying`, `.deployed`, `.failed`) are used when present.
- Progress measured as the share of the app rewritten since the deployment started, with growth shown as **100% + X MB**. Accept a new baseline after an app grows.
- Recent activity panel across all apps, with a 15 min / 1 h / 24 h / all window.
- **Today's tickets** tab: Jira tickets for the day, each covering one or more apps, a rolled-up status, a "Deployment validated" check, and a ready-to-paste Jira update. Ticket link format setting.

**Console**
- Version for each tool shown in the sidebar.
- Fix: elements marked hidden now stay hidden everywhere (affected the sign-in fields).
- Fix: a ticket linked after a deployment had started or finished now credits that deployment.

## 0.1.0 (2026-11-08)

First complete build of the WASVC workflow.

**Console UI**
- Six-step wizard: Connect, Job Source, Scan Versions, Select & Normalize, Validate & Review, Package. Every step can be opened from the step bar.
- Version scan of every `mapping.xml` under a source folder, listing folder, job, key, value and line number for each hit.
- Matches `nd…` and `ihs_plg_…` versions, including inside names and `.tar.gz` package names.
- Separate target and approved list for WebSphere ND and the IHS plugin.
- Per-folder Normalize / Keep / Remove. Remove only leaves a folder out of the ZIP.
- Protected files (whole mapping block; matches with or without the script extension) and protected strings (single line, any case).
- Optional **Retarget job group** and **Rename versions in job names**, both off by default.
- Well-formed XML check, mapping structure warnings, and a before/after review.
- In-browser ZIP build with `WASVC_MANIFEST.txt`; download, or send to the output folder through the backend.
- Output folder defaults to the source folder's parent.

**Backend**
- Zero-dependency Node.js 18+ server with a JSON API (`/api/health`, `/api/folders`, `/api/read`, `/api/upload`).
- `local` source (working) and `sftp` source over SSH (tested against a simulated server). The `blcli` source is a placeholder.
- Localhost-only by default, path containment, ZIP-only uploads, no silent overwrites, Host and Origin checks.

**Tools**
- `tools/probe/`: read-only environment check (Windows and Linux) and a one-job export test (`try-export.nsh`) for BSA 25.4.
