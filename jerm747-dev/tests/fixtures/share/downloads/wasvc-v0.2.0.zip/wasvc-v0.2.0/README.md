Test stand-in for the build.
