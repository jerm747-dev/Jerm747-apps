"""Rebuild Closet Nigel's supplementary animation atlas and grip manifest.

Run python art-direction/build_motion.py from any directory with Pillow and
Inkscape installed. Legacy frame IDs 0–21 continue to address nigel-actions.
"""
from dataclasses import fields, replace
import json
import math
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from PIL import Image
from nigel_rig import Pose, group, head_art, leg, p as old, top


SITE = Path(__file__).resolve().parents[1]
GAME = (SITE / "dist" if (SITE / "dist").is_dir() else SITE) / "returnity"
CELL = (240, 216)
COLUMNS = 8
WORLD_SCALE = 0.32 * 50 / 187
FOOT_Y = 199 / 0.32 - 410
poses = []
clips = {}
grips = {}


def frame(pose):
    """Reuse repeat drawings across cycles, then pack new cells in authoring order."""
    if pose in old:
        return old.index(pose)
    if pose in poses:
        return len(old) + poses.index(pose)
    poses.append(pose)
    return len(old) + len(poses) - 1


def blend(a, b, step=0.5):
    """Draw an articulated passing pose by blending individual joints."""
    def between(lo, hi):
        if isinstance(lo, tuple):
            return tuple(between(x, y) for x, y in zip(lo, hi))
        if isinstance(lo, str):
            return lo if step < 0.5 else hi
        return lo + (hi - lo) * step
    return Pose(**{f.name: between(getattr(a, f.name), getattr(b, f.name))
                   for f in fields(Pose)})


def numbered(name, *values):
    clips[name] = [value if isinstance(value, int) else frame(value) for value in values]


def rot(point, degrees):
    c, s = math.cos(math.radians(degrees)), math.sin(math.radians(degrees))
    return point[0] * c - point[1] * s, point[0] * s + point[1] * c


def grip_frame(pose, grip, span=6.0, height_difference=0.0):
    """Solve two elbows and palms around the prop's anchor, then record it.

    The near hand meets the left of a case handle and the far hand meets the
    right. Actors use a wider, staggered collar grip. All attachment points
    are in right-facing gameplay units at player height 50.
    """
    def solve(rear):
        side = 1 if rear else -1
        world_x = grip[0] + side * span / 2
        world_y = grip[1] + side * height_difference / 2
        target = rot((world_x / WORLD_SCALE - pose.x,
                      world_y / WORLD_SCALE + FOOT_Y - pose.y), -pose.lean)
        # Palm angles keep the knuckles aligned with a handle or collar.
        direction = (-22 if rear else 4) - pose.lean
        palm = rot((24, 0), direction)
        wrist = (target[0] - palm[0], target[1] - palm[1])
        start = (29, -127) if rear else (-35, -135)
        dx, dy = wrist[0] - start[0], wrist[1] - start[1]
        distance = max(1, math.hypot(dx, dy))
        # Prefer an elbow-down bend, with foreshortening on tight holds.
        half = distance * 0.5
        bend = math.sqrt(max(0, 78 * 78 - half * half))
        mid = ((start[0] + wrist[0]) / 2, (start[1] + wrist[1]) / 2)
        normal = (-dy / distance, dx / distance)
        elbow = (mid[0] + normal[0] * bend, mid[1] + normal[1] * bend)
        return elbow, wrist, direction

    index = frame(replace(pose, arm=solve(False), other=solve(True), mode="fist"))
    grips[index] = [round(x, 2) for x in grip]
    return index


def palm_anchor(index, pose):
    """One-handed releases track the actual center of the near palm."""
    _, wrist, angle = pose.arm
    offset = rot((24, 0), angle)
    palm = rot((wrist[0] + offset[0], wrist[1] + offset[1]), pose.lean)
    grips[index] = [round((palm[0] + pose.x) * WORLD_SCALE, 2),
                    round((palm[1] + pose.y - FOOT_Y) * WORLD_SCALE, 2)]


def palm_frame(pose):
    index = frame(pose)
    palm_anchor(index, pose)
    return index


# Walking makes heel contact, accepts weight, passes, then pushes off. Running
# retains all six original cels, with a longer reach and flight between steps.
walk_a = Pose(2, 3, ((43,85),(77,181),-9), ((-33,84),(-82,167),12),
              ((-58,-64),(-4,-53),2), ((57,-80),(78,-93),-18))
walk_b = Pose(7, 5, ((37,86),(31,176),0), ((-27,89),(-69,148),20),
              ((-59,-65),(-5,-45),4), ((59,-83),(78,-100),-23))
walk_c = Pose(-2, 2, ((-5,88),(-24,185),3), ((48,70),(23,132),6),
              ((-40,-63),(26,-50),-8), ((47,-73),(54,-52),5))
walk_d = Pose(2, 3, ((-36,83),(-91,165),15), ((49,86),(75,181),-8),
              ((-12,-71),(57,-83),-17), ((34,-67),(26,-32),11))
walk_e = Pose(7, 5, ((-26,84),(-67,145),20), ((34,81),(31,177),0),
              ((-12,-67),(52,-79),-16), ((32,-68),(22,-37),11))
walk_f = Pose(-2, 2, ((45,68),(18,131),6), ((-11,88),(-30,186),3),
              ((-27,-63),(37,-61),-10), ((46,-74),(49,-51),4))
numbered("idle", 0, 20)
numbered("walk", walk_a, walk_b, walk_c, walk_d, walk_e, walk_f)
numbered("run", replace(old[1], near=((86,59),(121,171),-13), far=((-53,66),(-153,120),29)),
         1, 2, 3, replace(old[4], far=((87,58),(121,171),-13), near=((-56,65),(-150,120),29)), 4, 5, 6)

# Lane travel shortens the upstage foot in perspective and gives the downstage
# leg a wider swing. The two routes have different weight and head direction.
lane_in = replace(old[0], y=4, lean=8, look=-5,
                  near=((33,73),(21,135),14), far=((-27,86),(-63,177),0),
                  arm=((-53,-73),(0,-63),-12))
lane_out = replace(old[0], y=2, lean=7, look=-6,
                   near=((14,88),(9,180),0), far=((-4,64),(-13,126),18),
                   arm=((-27,-64),(37,-67),-14))
lane_in_pass = replace(blend(lane_in,lane_out), y=-4, near=((35,71),(-5,161),5),
                       far=((-21,85),(-47,164),3))
lane_out_pass = replace(blend(lane_out,lane_in), y=7, near=((27,80),(25,163),3),
                        far=((-32,67),(-28,149),10))
numbered("laneUp", lane_in, lane_in_pass, lane_out, lane_out_pass)
toward_a = replace(walk_a, lean=-4, look=4, near=((56,85),(71,182),-2),
                   far=((-24,64),(-58,145),16), arm=((-63,-67),(-3,-47),3))
toward_b = replace(walk_d, lean=-4, look=4, near=((44,56),(19,138),14),
                   far=((-9,84),(-35,182),-2), arm=((-19,-71),(46,-69),-11))
numbered("laneDown", toward_a, replace(walk_c, lean=-2, look=4), toward_b,
         replace(walk_f, lean=-2,look=3))

# The jump phases are individually addressable so physics can linger at the
# apex, change direction in midair, and interrupt the landing immediately.
squat = Pose(117, 31, ((86,21),(26,67),0), ((-51,23),(-74,67),0),
             ((-71,-63),(-106,-20),17), ((72,-69),(57,-27),28),'open',-17)
spring = Pose(-3, 9, ((32,96),(5,178),17), ((-33,86),(-77,165),22),
              ((-77,-142),(-54,-225),-69), ((84,-153),(102,-216),-69),'fist',-4)
extended = replace(old[9], lean=-4, near=((78,48),(64,135),3),
                   far=((-40,73),(-111,136),27),
                   arm=((-90,-145),(-99,-209),-78),other=((91,-126),(126,-171),-37))
apex = Pose(13,-7, ((91,21),(50,88),9), ((14,54),(-55,93),24),
            ((-104,-117),(-149,-129),-20), ((88,-131),(146,-151),-17),'open',4)
toe_touch = Pose(0,-3, ((44,80),(53,170),12), ((-26,89),(-72,150),23),
                 ((-85,-80),(-107,-33),36), ((86,-105),(134,-87),13),'open',1)
recoil = replace(squat, y=81, lean=18, near=((76,49),(36,103),0),
                 far=((-38,55),(-62,103),0), arm=((-42,-66),(35,-51),7),
                 other=((64,-80),(110,-79),0), look=-8)
numbered("jump", squat, spring, 9, extended, apex, 10, toe_touch, recoil)
numbered("land", clips["jump"][6], clips["jump"][7], blend(recoil,old[0],.56), 0)
numbered("crouch", blend(old[0],old[8]), 8, replace(squat, mode="case",
         arm=((-40,-65),(28,-44),5)), 8)
numbered("skid", replace(old[7], y=25,lean=-27,near=((70,63),(134,151),-14),
                         far=((-51,74),(-71,159),-4)),
         7, replace(old[7], y=58, near=((67,48),(118,124),-4),
                    far=((-44,48),(-70,126),0)), blend(old[7],old[0],.6))
numbered("flip", blend(extended,old[11],.43), 11,
         replace(old[11],y=48,lean=41,near=((76,-2),(16,41),29),
                 far=((9,15),(-51,37),37),look=-20), apex)
numbered("dive", replace(old[11],lean=42), 12,
         replace(old[12],lean=72,near=((-68,45),(-147,68),17),
                 far=((-69,15),(-163,21),19)), blend(old[12],toe_touch,.62))
numbered("pound", replace(apex, y=17, arm=((-70,-150),(-39,-201),-54)),
         13, replace(old[13],y=8,lean=1,near=((32,96),(30,177),-2),
                     far=((-17,88),(-28,173),-1)), clips["jump"][7])

# Actors first reach the case on key 2; the case retains the same world-space
# handle while descending and then climbs from shin height to the chest.
reach = Pose(52, 32, ((66,64),(29,132),0), ((-45,65),(-71,132),0),
             ((6,-62),(77,-44),18), ((82,-89),(122,-72),17),'open',-13)
floor = Pose(126, 48, ((89,15),(33,58),-1), ((-48,21),(-76,58),0),look=-23)
loaded = replace(floor, y=114, lean=40, near=((85,29),(35,70),0),
                 far=((-44,27),(-74,70),0), look=-20)
half_lift = replace(recoil, y=65,lean=27,near=((74,50),(36,119),0),
                    far=((-42,61),(-70,119),0),look=-14)
carry = replace(old[0],y=9,lean=-5,look=4,near=((45,78),(27,174),0),
                far=((-25,80),(-65,174),0))
front = grip_frame(carry,(11.4,-30.2),5.3)
contact = grip_frame(floor,(13,-16.4),5.3)
numbered("liftCase", reach, contact, grip_frame(loaded,(13.4,-18.5),5.3),
         grip_frame(half_lift,(13.6,-24.9),5.3), front)
grips[clips["liftCase"][0]] = [13,-16.4]
numbered("carryIdle",front,grip_frame(replace(carry,y=12,look=3),(11.35,-29.8),5.3))
carry_steps = []
for step, base, shift in zip(range(6), (walk_a,walk_b,walk_c,walk_d,walk_e,walk_f), (0,.4,-.3,0,.4,-.3)):
    loaded_step = replace(base, lean=-4,look=3)
    carry_steps.append(grip_frame(loaded_step,(11.5+(step%3)*.15,-30+shift),5.3))
numbered("carryWalk",*carry_steps)

# Grapple hands are staggered vertically at shoulder/collar height. The broad
# low stance bears the opponent's weight. For the hip toss, the collar travels
# from front, over the pivoting shoulder, and out along the extended arm.
lunge = replace(old[14], y=20, lean=24,near=((81,71),(85,162),0),
                far=((-51,69),(-118,154),14),look=-14)
hold = replace(old[21],y=45,lean=15,near=((69,55),(51,139),0),
               far=((-49,58),(-102,137),3),look=-10)
grasp = grip_frame(lunge,(17.3,-33.9),4.2,5.2)
clinch = grip_frame(hold,(13.4,-31.2),4.2,5.2)
numbered("grapple",grip_frame(lunge,(19.2,-32.8),4.2,5.2),grasp,clinch,
         grip_frame(replace(hold,y=50,look=-8),(13.1,-30.5),4.2,5.2))
grapple_steps = []
for i, stride in enumerate((walk_a,walk_c,walk_d,walk_f)):
    def shorten(limb):
        knee,ank,angle=limb
        return ((knee[0],knee[1]-14),(ank[0],ank[1]-27),angle)
    weight = replace(stride,y=stride.y+27,lean=17,look=-9,
                     near=shorten(stride.near),far=shorten(stride.far))
    grapple_steps.append(grip_frame(weight,(14.0+(i%2),-31.5+(i%2)*.4),4.4,4.6))
numbered("grappleWalk",*grapple_steps)
hip = replace(floor,y=85,lean=-8,near=((79,36),(41,99),0),
              far=((-52,42),(-83,99),0),look=0)
pivot = replace(half_lift,y=39,lean=-22,near=((62,58),(44,145),0),
                far=((-40,62),(-79,145),0),look=10)
push = replace(old[17],y=20,lean=32,look=-14,
               arm=((57,-151),(144,-154),-5),other=((81,-136),(158,-145),-5))
press = palm_frame(push)
numbered("flipThrow",clinch,grip_frame(hip,(9.4,-30.1),3.4,4.5),
         grip_frame(pivot,(0.6,-39),3,3),grip_frame(replace(old[17],lean=10), (7.7,-43.2),3,2),
         press,palm_frame(blend(push,old[21],.57)))
case_load = replace(hold,lean=-10,look=7)
numbered("caseThrow",front,grip_frame(case_load,(7,-31),5.3),
         grip_frame(replace(old[14],lean=19),(16.5,-33),5.3),17,
         palm_frame(replace(old[17],y=13,lean=28,look=-14)),
         palm_frame(blend(old[17],old[21],.67)))
palm_anchor(17,old[17])

# Wide articulated silhouettes for each attack: gather, strike, overshoot,
# retract. Nigel keeps his original CD during an offer, catch or idle.
fire_load = replace(old[21], y=18,lean=-14,look=6,
                    arm=((-83,-101),(-69,-154),-75))
fire_release = replace(old[17],y=5,lean=12,look=-7,
                       arm=((49,-138),(135,-146),-4))
numbered("fire",fire_load,blend(fire_load,fire_release,.5),fire_release,
         replace(fire_release,lean=4,arm=((20,-124),(96,-128),-4)))
guard = replace(old[21],y=5,lean=-3,arm=((-62,-100),(-24,-154),-50))
numbered("jab",21,blend(old[21],old[14],.57),14,
         replace(old[14],lean=20,arm=((62,-145),(161,-151),-3)),guard)
numbered("cross",guard,replace(old[21],lean=9,look=-6),15,
         replace(old[15],lean=32,other=((111,-143),(212,-157),-10)),
         blend(old[15],guard,.68))
chamber = replace(old[16],lean=-8,near=((85,6),(32,68),13))
numbered("kick",guard,chamber,16,
         replace(old[16],lean=-17,near=((91,-16),(208,-57),-22)),chamber,guard)
numbered("hurt",replace(old[18],lean=-27,look=-9,
         arm=((-77,-135),(-121,-190),-96)),18,
         replace(old[18],y=30,lean=-11,look=1,arm=((-60,-106),(-46,-158),-70)),guard)
offer=replace(old[19],lean=12,arm=((33,-107),(117,-126),-6),look=-7)
numbered("handoff",0,19,offer,replace(offer,lean=8,look=-4))
catch=replace(old[19],y=27,lean=-12,arm=((-37,-95),(26,-122),-29),look=7)
numbered("collect",replace(offer,mode="open"),19,catch,blend(catch,old[0],.54),0)
signal=replace(old[0],lean=-4,look=-8,arm=((-79,-199),(-56,-275),-74),
               other=((81,-89),(110,-116),-33),mode="open")
numbered("backup",replace(guard,look=-9),blend(guard,signal,.54),signal,
         replace(signal,look=-12,arm=((-84,-202),(-70,-277),-82)),guard)


def manifest_source():
    entries = ",\n".join(f"    {name}: {json.dumps(ids)}" for name, ids in clips.items())
    grip_entries = ",\n".join(f"    {i}: {json.dumps(grips[i])}" for i in sorted(grips))
    return f"""// Generated by art-direction/build_motion.py. Legacy cells use IDs 0–21.
// Subsequent IDs index nigel-motion.webp with (id - 22) across eight columns.
// Grips are relative to Nigel's feet at height 50, right-facing and positive y down.
(function (root) {{
  const clips = {{
{entries}
  }};
  const grips = {{
{grip_entries}
  }};
  const motion = {{ clips, grips }};
  root.ReturnityMotion = motion;
  if (typeof module !== "undefined" && module.exports) module.exports = motion;
}})(globalThis);
"""


def render():
    cells=[]
    for i,pose in enumerate(poses):
        body = (leg((13,0),*pose.far,True) + leg((-10,0),*pose.near,False)
                + top(pose.lean,0,pose.arm,pose.other,pose.mode,pose.look))
        body = group(body, f"translate({350+pose.x} {410+pose.y})")
        cells.append(f'<svg x="{CELL[0]*(i%COLUMNS)}" y="{CELL[1]*(i//COLUMNS)}" '
                     f'width="{CELL[0]}" height="{CELL[1]}" viewBox="0 0 750 675">{body}</svg>')
    width = COLUMNS*CELL[0]
    height = math.ceil(len(poses)/COLUMNS)*CELL[1]
    out = GAME / "assets"
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
           f'width="{width}" height="{height}">{head_art(out / "closet.webp")}{"".join(cells)}</svg>')
    with TemporaryDirectory() as work:
        source, bitmap = Path(work)/"atlas.svg", Path(work)/"atlas.png"
        source.write_text(svg)
        subprocess.run(["inkscape",str(source),"--export-type=png",
                        f"--export-filename={bitmap}"],check=True)
        with Image.open(bitmap) as sheet:
            sheet.save(out/"nigel-motion.webp",quality=90,method=6,alpha_quality=100)
    (GAME/"motion-clips.js").write_text(manifest_source())


if __name__ == "__main__":
    render()
