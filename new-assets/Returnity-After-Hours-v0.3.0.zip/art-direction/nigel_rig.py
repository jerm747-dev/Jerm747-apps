"""Vector cutout rig for Closet Nigel. Coordinates are in original concept-art pixels.

The 22 legacy poses are used as exact mid-poses and animation references.
The runtime continues to load their original atlas cells.
"""
import base64
import math
from dataclasses import dataclass
from io import BytesIO
from PIL import Image

def path(d, fill='none', stroke='#100c0a', sw=6):
 return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>'
def ellipse(x,y,rx,ry,fill,stroke='none',sw=0):
 return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def group(children, transform):
 return f'<g transform="{transform}">{children}</g>'
def tween(a,b,t):return (a[0]*(1-t)+b[0]*t,a[1]*(1-t)+b[1]*t)
def norm(v):
 h=math.hypot(*v)
 return (-v[1]/h,v[0]/h)
def add(a,n,w):return (a[0]+n[0]*w,a[1]+n[1]*w)
def vstr(p):return f'{p[0]:.1f} {p[1]:.1f}'
def tube(a,b,c,wa,wb,wc,fill,outline=6):
 n1=norm((b[0]-a[0],b[1]-a[1]));n2=norm((c[0]-b[0],c[1]-b[1]));avg=(n1[0]+n2[0],n1[1]+n2[1]);h=math.hypot(*avg)
 n=(avg[0]/(h or 1),avg[1]/(h or 1))
 aa,bb,cc=[add(p,m,w) for p,m,w in [(a,n1,wa),(b,n,wb),(c,n2,wc)]]
 am,bm,cm=[add(p,m,-w) for p,m,w in [(a,n1,wa),(b,n,wb),(c,n2,wc)]]
 c1=tween(aa,bb,.85);c2=tween(bb,cc,.17);d1=tween(cm,bm,.83);d2=tween(bm,am,.15)
 d=f'M {vstr(aa)} L {vstr(c1)} Q {vstr(bb)} {vstr(c2)} L {vstr(cc)} Q {vstr(c)} {vstr(cm)} L {vstr(d1)} Q {vstr(bm)} {vstr(d2)} L {vstr(am)} Q {vstr(a)} {vstr(aa)} Z'
 return path(d,fill,sw=outline)
def foot(x,y,angle,back=False):
 black='#110c0b';white='#dddce0' if back else '#fffafa';sole='#a9a6a8' if back else '#e6e2e4'
 s=path('M -29 -25 Q -11 -35 8 -22 L 18 -12 Q 26 -10 37 -13 Q 57 -16 67 -5 Q 74 2 73 12 Q 65 22 41 23 L -30 23 Q -38 20 -38 10 L -36 -13 Z',white,sw=6)
 s+=path('M -37 9 Q 13 17 46 13 Q 62 12 72 5 L 73 15 Q 65 26 36 27 L -29 27 Q -37 25 -39 18 Z',sole,sw=4.5)
 s+=path('M 18 -13 L 28 -4 M 25 -15 L 36 -7 M 34 -14 L 42 -8',sw=3)
 s+=path('M -9 -18 L -5 -10 L 3 -11 L -2 -5 L 0 2 L -7 -2 L -14 2 L -12 -6 L -18 -10 L -10 -11 Z',black,sw=1)
 return group(s,f'translate({x} {y}) rotate({angle})')
def leg(a,k,ank,angle,back):
 x,y=ank;fill='#376ea4' if back else '#4e90c9'
 s=tube(a,k,ank,35,28,29,fill)
 # Shallow indigo inseam and folded cuff.
 the=tween(k,ank,.88);n=norm((ank[0]-k[0],ank[1]-k[1]))
 s+=path(f'M {vstr(add(tween(a,k,.23),norm((k[0]-a[0],k[1]-a[1])),-14))} Q {vstr(add(k,n,-14))} {vstr(add(tween(k,ank,.4),n,-16))}',stroke='#244260',sw=3.8)
 s+=foot(*ank,angle,back)
 d='M '+' L '.join(vstr(p) for p in (add(the,n,33),add(ank,n,36),add(ank,n,-35),add(the,n,-31)))+' Z'
 s+=path(d,'#528ac0' if back else '#72add9',sw=5.5)
 return s
def sleeve(a,b,c,rear=False):
 fill='#a19ba1' if rear else '#c8c3c6'
 s=tube(a,b,c,28,25,21,fill)
 at=tween(b,c,.78);n=norm((c[0]-b[0],c[1]-b[1]))
 d='M '+' L '.join(vstr(p) for p in (add(at,n,23),add(c,n,24),add(c,n,-24),add(at,n,-22)))+' Z'
 s+=path(d,'#aaa3aa' if rear else '#b7b1b6',sw=4.7)
 return s
def hand(x,y,angle=0,case=False,openp=False):
 s=''
 if case:
  s+=path('M 22 -11 L 26 -67 L 90 -57 L 86 11 L 80 16 Z','#f2f3f4',sw=6)
  s+=path('M 80 16 L 85 -54 M 31 -61 L 42 -59',sw=3)
  s+=ellipse(57,-28,15,16,'#f1ca3b','#20132b',2)
  s+=path('M 57 -43 A 15 15 0 0 1 69 -20 L 57 -28 Z','#ed56a2','none',0)
  s+=path('M 70 -23 A 15 15 0 0 1 48 -17 L 57 -28 Z','#43a2dc','none',0)
  s+=ellipse(57,-28,5,5,'#f6efde','#181217',2)
 if openp:
  s+=path('M -6 -16 Q 8 -21 19 -13 L 30 -19 Q 36 -22 38 -17 Q 39 -13 31 -8 L 50 -8 Q 56 -9 56 -3 Q 56 1 48 3 Q 48 10 40 10 Q 29 22 9 20 L -6 14 Z','#ff970e',sw=5)
 else:
  s+=path('M -6 -16 Q 4 -21 14 -23 Q 22 -27 30 -21 L 35 -15 Q 41 -14 43 -7 L 42 0 Q 44 8 38 12 Q 35 18 28 19 Q 21 24 7 21 L -6 15 Z','#ff960c',sw=5.5)
  s+=path('M 30 -12 L 39 -8 M 30 -3 L 40 1 M 28 6 L 37 10',sw=2.8)
 return group(s,f'translate({x} {y}) rotate({angle})')

# Cropped original upper silhouette, including the curls, headphones, face and neck.
def head_art(asset):
 # The approved transparent portrait is the source for the original head.
 portrait = Image.open(asset).convert('RGBA').resize((384, 590), Image.Resampling.LANCZOS)
 encoded = BytesIO()
 portrait.save(encoded, format='PNG')
 bitmap = base64.b64encode(encoded.getvalue()).decode('ascii')
 return f'''<defs><clipPath id="faceClip"><path d="M 39 0 H 332 V 203 L 245 201 L 231 222 L 208 211 L 190 197 L 152 180 L 54 182 Z"/></clipPath><g id="head" clip-path="url(#faceClip)"><image width="384" height="590" xlink:href="data:image/png;base64,{bitmap}"/></g></defs>'''
def torso():
 # Torso silhouette and backpack from the original concept, authored as jointed vector parts.
 s=path('M 127 223 Q 85 211 64 235 Q 45 245 43 263 Q 27 269 24 295 L 22 313 L 17 318 Q 9 341 16 361 Q 22 380 45 383 Q 67 404 96 397 L 128 391 Q 145 384 150 367 L 159 249 Z','#ff9d0c',sw=7)
 s+=path('M 66 239 Q 47 263 44 309 M 35 308 L 62 312 M 41 318 Q 36 348 44 372 M 81 246 Q 64 260 60 306 M 57 319 Q 49 351 60 370 Q 68 384 95 375',sw=4.7)
 s+=path('M 128 220 Q 156 203 181 208 L 226 204 Q 248 211 256 245 Q 269 291 260 331 L 254 378 Q 212 395 161 381 Q 144 379 131 368 Q 143 296 122 257 Q 116 234 128 220 Z','#c6c1c4',sw=7)
 s+=path('M 135 365 Q 167 374 196 374 Q 234 376 254 368 L 254 378 Q 198 399 157 381 L 135 377 Z','#aaa4aa',sw=4.5)
 s+=path('M 118 211 Q 102 198 120 188 Q 159 169 193 190 Q 218 201 231 219 Q 215 222 202 232 Q 160 214 137 233 Q 119 240 118 226 Z','#c8c3c5',sw=6)
 s+=path('M 144 199 Q 165 192 191 204 M 230 217 Q 237 239 237 267',sw=4)
 s+=path('M 168 221 Q 188 216 201 232 Q 216 257 192 302 L 180 326 L 162 320 Q 185 273 182 252 Q 179 237 165 235 Z','#ffaa10',sw=6)
 return group(s,'translate(-190 -375)')
def top(angle,dy,arm,other,mode,headlean=0):
 # arms are stored in waist-local coordinates.
 b,c,w=arm;b2,c2,w2=other
 shoulder=(-35,-135);far=(29,-127)
 rear=sleeve(far,b2,c2,True)+hand(*c2,w2)
 s=rear+torso()
 # The limited rotation pivots near the back of the neck.
 s+=group('<use xlink:href="#head"/>',f'translate(-190 -375) rotate({headlean} 205 198)')
 s+=sleeve(shoulder,b,c)+hand(*c,w,mode=='case',mode=='open')
 return group(s,f'translate(0 {dy}) rotate({angle})')
@dataclass
class Pose:
 y:float=0; lean:float=0
 # knees, ankles, shoe orientation, relative to waist at neutral height
 near:tuple=((35,93),(11,184),0);far:tuple=((-24,89),(-63,184),0)
 arm:tuple=((-59,-67),(19,-51),-9);other:tuple=((58,-73),(46,-38),5)
 mode:str='case';look:float=0; x:float=0
I=Pose
p=[
 I(),
 I(-2,9,((68,75),(83,183),-6),((-43,79),(-139,153),19),((-51,-52),(24,-63),-15),((69,-92),(82,-142),-54)),
 I(6,12,((48,79),(21,177),0),((1,74),(-88,109),39),((-59,-58),(8,-47),0),((76,-98),(82,-155),-63)),
 I(-9,15,((-20,81),(-67,189),17),((91,59),(46,110),12),((-58,-47),(-38,-18),24),((65,-126),(113,-145),-14)),
 I(-2,9,((-48,72),(-143,138),30),((65,75),(83,183),-5),((19,-76),(74,-87),-13),((15,-72),(-18,-24),28)),
 I(6,12,((-1,68),(-96,114),39),((34,80),(13,177),0),((23,-104),(71,-122),-18),((10,-72),(-13,-28),27)),
 I(-9,15,((92,54),(42,113),12),((-25,86),(-74,189),15),((28,-96),(76,-111),-10),((10,-75),(-19,-27),22)),
 I(46,-21,((60,56),(134,135),-9),((-59,59),(-79,137),-6),((-46,-61),(47,-48),0),((55,-85),(114,-100),-15),'open',9),
 I(86,23,((74,46),(16,96),0),((-48,42),(-71,98),0),((-7,-65),(66,-70),-8),((72,-102),(93,-76),12),'case',-10),
 I(0,0,((78,49),(61,110),12),((-34,79),(-103,122),26),((-64,-115),(-69,-174),-75),((86,-99),(104,-158),-64),'fist',-2),
 I(0,-8,((81,61),(83,157),-10),((-44,69),(-119,106),24),((-104,-134),(-121,-200),-78),((89,-158),(116,-198),-46),'open',4),
 I(35,28,((58,21),(-2,73),20),((-16,31),(-71,62),34),((-7,-79),(46,-35),38),((55,-86),(69,-47),56),'fist',-12),
 I(14,65,((-48,55),(-130,98),18),((-67,25),(-160,48),20),((-11,-206),(14,-293),-68),((56,-178),(78,-260),-64),'fist',-18),
 I(25,-4,((62,81),(65,154),1),((-38,63),(-20,151),-4),((-86,-181),(-57,-252),-56),((79,-169),(86,-248),-75),'fist',-3),
 I(8,16,((75,86),(74,173),0),((-47,78),(-102,175),5),((50,-137),(142,-153),-9),((66,-120),(65,-160),-63),'fist',-8),
 I(8,26,((66,87),(66,173),0),((-46,81),(-115,174),12),((-44,-81),(15,-105),-22),((98,-147),(197,-176),-16),'fist',-14),
 I(-1,-12,((83,-11),(185,-56),-25),((-27,84),(-55,186),0),((-67,-99),(-51,-162),-61),((60,-108),(89,-148),-43),'fist',5),
 I(4,19,((73,78),(70,179),-2),((-48,77),(-116,176),15),((62,-154),(157,-195),-23),((7,-60),(-21,-17),28),'open',-8),
 I(17,-20,((66,66),(77,167),0),((-38,72),(-97,165),-5),((-64,-128),(-97,-180),-94),((75,-135),(85,-187),-66),'open',-7),
 I(2,8,((32,91),(20,182),0),((-28,88),(-69,182),0),((20,-86),(79,-101),-9),((58,-73),(45,-42),8),'case',0),
 I(5,-1,((36,89),(12,180),0),((-29,85),(-67,180),0),((-58,-65),(23,-51),-12),((57,-74),(44,-41),10),'case',1),
 I(11,-9,((62,80),(53,173),0),((-41,76),(-85,172),0),((-72,-93),(-42,-151),-50),((78,-119),(91,-157),-62),'fist',5)
]
