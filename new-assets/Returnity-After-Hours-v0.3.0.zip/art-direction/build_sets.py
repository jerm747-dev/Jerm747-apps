"""Build the scalable set flats from the Returnity character color key."""
from pathlib import Path
from html import escape
import json
here=Path(__file__).resolve().parent
site_root=here.parent
out=(site_root/'dist' if (site_root/'dist').is_dir() else site_root)/'returnity/assets'
key=json.loads((here/'color-key.json').read_text())
denim,brick,leaf,concrete,violet,signal=[key['ramps'][s] for s in ('Denim','Brick','Leaf','Concrete','Violet','Signal')]
INK='#282433'; SOFT='#484557'; SKY='#777caa'; FAR='#686986'; LAMP='#f8c67c'
def path(d,fill,stroke='none',width=0):
 return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"/>'
def box(x,y,w,h,r,fill,stroke='none',sw=0):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def dot(x,y,r,c):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>'
def group(x,y,body,scale=1):return f'<g transform="translate({x} {y}) scale({scale})">{body}</g>'
def word(x,y,t,size,c):return f'<text x="{x}" y="{y}" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-weight="bold" letter-spacing="1" font-size="{size}" fill="{c}">{escape(t)}</text>'
def save(name,vb,width,height,data):
 (out/name).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="{vb}">{data}</svg>')
def tree(x,y,s):
 trunk=path('M-5 1 Q-1-23-3-43L-17-54Q-20-60-16-58L0-48 12-62Q17-64 16-58L6-40 8 0Z',brick[3],INK,3)
 crown=path('M-39-56 C-55-57-59-78-45-86 Q-49-103-32-107 Q-26-125-9-117 Q6-136 21-118 Q42-123 46-105 Q62-102 57-83 Q69-62 49-55 Q44-39 24-43 Q9-32-5-44 Q-28-36-39-56Z',leaf[1],INK,3)
 shade=path('M-44-63 Q-31-57-25-64 Q-15-51-2-58 Q15-45 25-57 Q41-51 49-66 Q56-63 59-72 Q63-61 48-55 Q44-40 24-43 Q8-32-5-44 Q-31-34-44-63Z',leaf[2])
 return group(x,y,trunk+crown+shade+path('M-36-91Q-33-103-20-102 M-7-108Q1-117 11-111','none',leaf[0],3),s)
def windows(x,y,n,w=24,h=28,lit=False):
 res=''
 for i in range(n):
  a=x+i*(w+7);res+=box(a,y,w,h,2.3,INK)+box(a+2.1,y+2,w-4.2,h-4,1.2,(LAMP if lit and i%3!=1 else denim[3]))+path(f'M{a+w*.65} {y+2}v{h-4}','none',SOFT,1.5)
 return res
def terrace(x,w,y,color,lit=False):
 body=path(f'M0 220V{y+4}Q0 {y} 5 {y}H{w-3}Q{w} {y} {w} {y+4}V220Z',color,INK,2.6)
 body+=box(-2,y-3,w+4,8,2,concrete[2],INK,2.6)+box(0,y+6,w,5,0,brick[3])
 body+=windows(10,y+17,max(1,(w-18)//34),26,34,lit)
 return group(x,0,body)
def door(x,y,w,h,lit=False):
 return box(x,y,w,h,3,INK)+box(x+3,y+3,w-6,h-3,2,brick[2] if lit else denim[3])+box(x+7,y+8,w-14,h*.46,2,LAMP if lit else denim[2])+box(x+w-9,y+h*.62,4,2,1,concrete[0])
def storefront(x,w,base,label,lit=True):
 s=terrace(0,w,104,base,False)
 s+=box(3,153,w-6,15,3,INK)+word(w/2,164,label,8.3,'#eadab7')
 s+=door(w*.64,176,w*.2,42,lit)+box(10,175,w*.48,32,3,INK)+box(13,178,w*.48-6,26,1,LAMP if lit else denim[2])
 s+=path(f'M22 203l14-19h9l-14 19Z',brick[0] if lit else denim[1])
 return group(x,0,s)
def lamp(x):
 return group(x,0,path('M0 217V113 Q0 101 12 101 H26','none',INK,3)+path('M17 104 Q18 95 26 95 Q34 95 36 104Z',concrete[2],INK,2)+box(20,104,13,2.5,1,LAMP))
def arch(x,w):
 return group(x,0,path(f'M0 214V98H{w}V214H{w-27}V167Q{w-30} 128 {w*.5} 127Q27 127 27 167V214Z',concrete[2],INK,3)+box(-4,90,w+8,12,2,concrete[1],INK,3)+path(f'M0 109H{w}','none',concrete[3],3))
def shutter(x,w):
 return box(x,164,w,53,3,INK)+box(x+3,167,w-6,50,1,concrete[2])+''.join(path(f'M{x+6} {y}h{w-12}','none',concrete[3],1.2) for y in (177,187,197,207))
def studio(x):
 b=terrace(0,135,106,brick[2],True)+door(47,163,37,55,True)+box(39,156,54,7,2,brick[0],INK,2)
 b+=box(42,213,48,4,1,concrete[1],INK,1.5)+box(37,218,58,4,1,concrete[2],INK,1.5)
 return group(x,0,b)
def mural(x):
 # A painted sound wave in four large marks.
 return group(x,151,''.join(box(i*11,abs(2-i)*5,6,40-abs(2-i)*10,3,c) for i,c in enumerate((denim[0],signal[1],brick[0],LAMP,denim[1]))))
bg=box(0,-130,2160,460,0,SKY)+dot(365,-18,16,'#ebd6ac')
for i in range(39):
 x=i*62-24;y=65-(i*23%54)
 bg+=box(x,y,44+(i*7)%33,145-y,1,FAR)
 if i%4==0:bg+=box(x+12,y-6,21,8,1,FAR)
for x,y in [(18,17),(510,-8),(861,23),(1260,-12),(1720,4),(2030,16)]:
 bg+=group(x,y,path('M0 12Q4 7 16 7 Q23-3 34 3 Q45-1 52 8 Q66 7 72 12Z','#9594b1'))
bg+=box(0,148,2160,78,0,leaf[3])
bg+=studio(2)+terrace(150,169,117,concrete[2],True)+shutter(174,97)+storefront(330,149,denim[2],'RECORDS')+terrace(488,154,91,brick[2],True)+mural(516)+door(597,166,31,51)
bg+=arch(651,131)+terrace(793,196,110,violet[2],True)+shutter(828,89)+door(940,170,25,47)+storefront(1001,140,brick[2],'SOUND SERVICE',False)
bg+=terrace(1156,162,100,denim[2],True)+mural(1181)+shutter(1252,51)+arch(1333,157)+studio(1512)+terrace(1660,166,118,brick[2],True)+shutter(1699,84)+terrace(1834,112,113,concrete[2],False)+door(1886,166,33,51)
bg+=terrace(1960,175,90,brick[2],True)+door(2018,157,45,62,True)+box(1999,136,85,15,4,INK)+word(2041,147,'OPEN MIC',9,'#ffe7ae')+path('M2069 212l7-24h13l7 24Z',brick[0],INK,2)
# Show-night details are confined to the entrance, leaving a clean playable lane.
bg+=box(2013,153,55,66,4,brick[3],INK,2)+door(2019,157,43,62,True)
bg+=path('M2010 164l9-12h46l10 12Z',denim[2],INK,2.2)+path('M2012 165h61','none',LAMP,1.4)
bg+=box(1970,165,25,32,2,denim[3],INK,1.5)+box(1974,169,17,23,1,'#c39a87')
bg+=dot(1982.5,178,5.3,violet[2])+dot(1982.5,178,1.3,'#e8be91')+path('M1978 186h9','none',violet[2],1.4)
bg+=box(2083,164,22,26,2,concrete[3],INK,1.5)+box(2086,167,16,20,1,denim[0])+path('M2090 181v-7l8-2v7','none',denim[3],1.6)+dot(2089,182,2,denim[3])+dot(2097,180,2,denim[3])
bg+=path('M2072 209l5-17h10l5 17Z',denim[3],'none')+path('M2078 198l6-1 M2078 202l4-1','none',LAMP,1.25)
# A low, rounded ventilation duct and a few separated mortar strokes.
bg+=box(1863,148,17,8,2,concrete[3],INK,1.5)+path('M1867 151h9','none',concrete[1],1.3)
for x,y in [(23,170),(99,199),(272,182),(522,203),(605,148),(872,159),(1280,152),(1611,177),(2001,185),(2106,156),(2112,194)]:
 bg+=path(f'M{x} {y}h7l1-3 M{x+6} {y+5}h9','none',brick[3],.95)
bg+=box(0,220,2160,22,0,'#a7a3aa')+path('M0 242H2160','none',INK,3)+box(0,244,2160,100,0,'#797981')+path('M0 248H2160','none','#686875',2)
for x in range(74,2160,128):bg+=path(f'M{x} 237l3 4','none','#78757f',1.1)
for x,y,s in [(140,218,.90),(480,218,.64),(774,219,.79),(1142,218,.75),(1480,217,.95),(1824,218,.75),(2148,218,.87)]:bg+=tree(x,y,s)
for x in (310,973,1634,1942):bg+=lamp(x)
for i in range(3):save(f'district-{i}.svg',f'{i*720} -110 720 438',2160,1314,bg)
# Intimate converted-room stage. One spotlight cut and a taped center mark.
inside=box(0,-110,480,438,0,'#302e40')+box(0,31,480,150,0,violet[3])+path('M13 159V65Q13 54 24 54H456Q466 54 466 65V159Z',violet[1],INK,3)
inside+=path('M33 57H131Q120 94 81 107Q81 135 62 151H33Z',brick[2],INK,3)+path('M447 57H349Q360 94 399 107Q400 135 418 151H447Z',brick[2],INK,3)
inside+=path('M207 69h65l24 86H184Z',violet[0])+box(67,150,346,14,5,brick[2],INK,3)+path('M0 180Q220 172 480 180V328H0Z',concrete[2],INK,2.6)
for x in [73,369]:
 inside+=box(x,116,38,39,3,INK)+dot(x+19,135,11,concrete[3])+dot(x+19,135,5,denim[2])
inside+=path('M236 185h8 M240 183v4','none','#e5ceb1',1.8)+path('M240 155v-39l7-8 M234 156l6-2 7 2','none',INK,2.6)+path('M245 110l7-6','none',concrete[0],3.4)
save('room.svg','0 -110 480 438',1440,1314,inside)
